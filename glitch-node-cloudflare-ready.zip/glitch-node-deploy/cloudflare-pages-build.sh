#!/bin/bash
# This script runs on Cloudflare Pages build environment
set -e

echo "==> Installing pnpm"
npm install -g pnpm@latest

echo "==> Installing dependencies"
pnpm install --frozen-lockfile=false

echo "==> Building frontend"
pnpm --filter @workspace/glitch-node run build

echo "==> Build complete. Output: artifacts/glitch-node/dist/public"
