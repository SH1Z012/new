import { pgTable, serial, integer, numeric, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const deploymentStatusEnum = pgEnum("deployment_status", ["active", "completed", "exited"]);

export const botDeploymentsTable = pgTable("bot_deployments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  planId: integer("plan_id").notNull(),
  // Non-refundable principal — once set, cannot be returned to user
  principalAmount: numeric("principal_amount", { precision: 20, scale: 8 }).notNull(),
  // Accrued earnings — the only amount that can be withdrawn/returned on emergency exit
  accruedEarnings: numeric("accrued_earnings", { precision: 20, scale: 8 }).notNull().default("0"),
  status: deploymentStatusEnum("status").notNull().default("active"),
  deployedAt: timestamp("deployed_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
  lastPayoutAt: timestamp("last_payout_at"),
});

export const insertBotDeploymentSchema = createInsertSchema(botDeploymentsTable).omit({ id: true });
export type InsertBotDeployment = z.infer<typeof insertBotDeploymentSchema>;
export type BotDeployment = typeof botDeploymentsTable.$inferSelect;
