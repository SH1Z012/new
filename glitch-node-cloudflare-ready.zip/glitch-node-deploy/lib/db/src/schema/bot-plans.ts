import { pgTable, serial, text, numeric, integer, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const planTierEnum = pgEnum("plan_tier", ["starter", "pro", "elite", "ultra"]);

export const botPlansTable = pgTable("bot_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  minDeposit: numeric("min_deposit", { precision: 20, scale: 8 }).notNull(),
  maxDeposit: numeric("max_deposit", { precision: 20, scale: 8 }),
  dailyReturnRate: numeric("daily_return_rate", { precision: 10, scale: 6 }).notNull(),
  durationDays: integer("duration_days").notNull(),
  tier: planTierEnum("tier").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertBotPlanSchema = createInsertSchema(botPlansTable).omit({ id: true });
export type InsertBotPlan = z.infer<typeof insertBotPlanSchema>;
export type BotPlan = typeof botPlansTable.$inferSelect;
