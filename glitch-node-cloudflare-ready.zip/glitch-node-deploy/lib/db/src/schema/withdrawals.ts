import { pgTable, serial, integer, numeric, text, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const withdrawalStatusEnum = pgEnum("withdrawal_status", ["pending", "processing", "completed", "failed"]);
export const networkEnum = pgEnum("network", ["TON", "TRX", "ETH", "BSC"]);

export const withdrawalsTable = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Amount is ALWAYS from earnings balance only — principal is non-refundable
  amount: numeric("amount", { precision: 20, scale: 8 }).notNull(),
  // Dynamic fee columns (1%, 3%, or 5% based on withdrawal frequency)
  feeAmount: numeric("fee_amount", { precision: 20, scale: 8 }).notNull().default("0"),
  feePercent: integer("fee_percent").notNull().default(1),
  netAmount: numeric("net_amount", { precision: 20, scale: 8 }).notNull().default("0"),
  walletAddress: text("wallet_address").notNull(),
  network: networkEnum("network").notNull(),
  status: withdrawalStatusEnum("status").notNull().default("pending"),
  txHash: text("tx_hash"),
  // Only set AFTER payment provider webhook confirms the transaction
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertWithdrawalSchema = createInsertSchema(withdrawalsTable).omit({ id: true, createdAt: true });
export type InsertWithdrawal = z.infer<typeof insertWithdrawalSchema>;
export type Withdrawal = typeof withdrawalsTable.$inferSelect;
