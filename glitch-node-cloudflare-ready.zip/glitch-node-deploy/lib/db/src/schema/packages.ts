import { pgTable, serial, integer, numeric, timestamp, boolean, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const packageTypeEnum = pgEnum("package_type", ["PRIMARY", "COMPOUND"]);

// Valid investment amounts in GEL (fixed tiers)
export const VALID_PACKAGE_AMOUNTS = [25, 50, 100, 150, 400, 1000, 2500, 5000] as const;
export const PACKAGE_LIFESPAN_DAYS = 180;

export const packagesTable = pgTable("packages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  // Amount in GEL — must be one of the VALID_PACKAGE_AMOUNTS
  amount: numeric("amount", { precision: 20, scale: 8 }).notNull(),
  // PRIMARY = purchased with external deposit; COMPOUND = reinvested from earnings
  type: packageTypeEnum("type").notNull().default("PRIMARY"),
  isActive: boolean("is_active").notNull().default(true),
  // Each package expires exactly 180 days after creation
  createdAt: timestamp("created_at").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const insertPackageSchema = createInsertSchema(packagesTable).omit({ id: true, createdAt: true });
export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type Package = typeof packagesTable.$inferSelect;
