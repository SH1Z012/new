import { pgTable, serial, integer, numeric, text, timestamp, jsonb, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const transactionTypeEnum = pgEnum("transaction_type", [
  "deposit",
  "withdrawal",
  "earning",
  "referral_bonus",
  "compound",
  "emergency_exit",
]);

export const transactionStatusEnum = pgEnum("transaction_status", [
  "pending",
  "completed",
  "failed",
]);

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: transactionTypeEnum("type").notNull(),
  // Positive = credit, negative = debit. Uses numeric to avoid float rounding.
  amount: numeric("amount", { precision: 20, scale: 8 }).notNull(),
  // Fee and net breakdown (for withdrawals mainly; others have 0 fee)
  feeAmount: numeric("fee_amount", { precision: 20, scale: 8 }).notNull().default("0"),
  netAmount: numeric("net_amount", { precision: 20, scale: 8 }).notNull().default("0"),
  status: transactionStatusEnum("status").notNull().default("completed"),
  description: text("description").notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({ id: true, createdAt: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;
