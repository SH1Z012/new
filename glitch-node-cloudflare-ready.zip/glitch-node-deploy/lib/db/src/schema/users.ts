import { pgTable, serial, text, numeric, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  // telegramId is used for Telegram login; manual browser users get "manual_<username>"
  telegramId: text("telegram_id").notNull().unique(),
  username: text("username"),
  firstName: text("first_name"),
  lastName: text("last_name"),
  avatarUrl: text("avatar_url"),
  // ── Email + Password auth (nullable — Telegram users have no password) ───────
  email: text("email").unique(),
  passwordHash: text("password_hash"),
  // ── Balances ─────────────────────────────────────────────────────────────────
  // Earnings-only balance — principal is NEVER added here
  availableBalance: numeric("available_balance", { precision: 20, scale: 8 }).notNull().default("0"),
  totalEarnings: numeric("total_earnings", { precision: 20, scale: 8 }).notNull().default("0"),
  // Active principal = sum of all non-expired, active packages
  activePrincipal: numeric("active_principal", { precision: 20, scale: 8 }).notNull().default("0"),
  // Non-refundable lifetime principal invested (monotonically increasing)
  totalPrincipal: numeric("total_principal", { precision: 20, scale: 8 }).notNull().default("0"),
  // ── Click tracking — "No Click, No Time" ─────────────────────────────────────
  lastClickAt: timestamp("last_click_at"),
  nextAllowedClickAt: timestamp("next_allowed_click_at"),
  // ── Withdrawal tracking ───────────────────────────────────────────────────────
  lastWithdrawalAt: timestamp("last_withdrawal_at"),
  // ── Payout wallet — 48h security lockout on change ───────────────────────────
  walletAddress: text("wallet_address"),
  walletUpdatedAt: timestamp("wallet_updated_at"),
  // ── Identity ─────────────────────────────────────────────────────────────────
  referralCode: text("referral_code").notNull().unique(),
  referredById: integer("referred_by_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
