/**
 * Background cron job — expires packages whose expiresAt <= now().
 * Flips isActive = false and decrements the user's activePrincipal.
 * Runs every 5 minutes. Safe to run concurrently — uses per-package row locks.
 */
import { db, packagesTable, usersTable } from "@workspace/db";
import { eq, lte, and, sql } from "drizzle-orm";
import { logger } from "./logger";

let isRunning = false;

export async function expirePackages(): Promise<void> {
  if (isRunning) return; // Prevent overlapping runs
  isRunning = true;
  try {
    const now = new Date();

    // Find all active packages that have expired
    const expired = await db
      .select()
      .from(packagesTable)
      .where(and(eq(packagesTable.isActive, true), lte(packagesTable.expiresAt, now)));

    if (expired.length === 0) return;

    logger.info({ count: expired.length }, "Expiring packages");

    for (const pkg of expired) {
      await db.transaction(async (tx) => {
        // Lock the package row
        const [locked] = await tx
          .select()
          .from(packagesTable)
          .where(eq(packagesTable.id, pkg.id))
          .for("update")
          .limit(1);

        if (!locked || !locked.isActive) return; // Already expired by another worker

        await tx
          .update(packagesTable)
          .set({ isActive: false })
          .where(eq(packagesTable.id, locked.id));

        // Decrement activePrincipal — clamp to 0 to avoid negative values
        await tx
          .update(usersTable)
          .set({
            activePrincipal: sql`GREATEST(0, ${usersTable.activePrincipal} - ${locked.amount}::numeric)`,
            updatedAt: new Date(),
          })
          .where(eq(usersTable.id, locked.userId));
      });
    }

    logger.info({ count: expired.length }, "Package expiry complete");
  } catch (err) {
    logger.error(err, "Package expiry error");
  } finally {
    isRunning = false;
  }
}

export function startExpiryWorker(intervalMs = 5 * 60 * 1000): NodeJS.Timeout {
  logger.info("Package expiry worker started (interval: 5m)");
  return setInterval(expirePackages, intervalMs);
}
