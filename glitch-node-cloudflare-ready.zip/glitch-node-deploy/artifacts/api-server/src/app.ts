import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// ── CORS ─────────────────────────────────────────────────────────────────────
// ALLOWED_ORIGINS env: comma-separated list of allowed frontend origins.
// Example: https://glitch-node.pages.dev,https://www.mysite.com
// If not set → falls back to permissive (useful for local dev / Railway preview).
const rawOrigins = process.env["ALLOWED_ORIGINS"];
const corsOptions = rawOrigins
  ? {
      origin: rawOrigins.split(",").map((o) => o.trim()).filter(Boolean),
      credentials: false,
    }
  : true; // allow all origins when env is not set (dev fallback)

app.use(pinoHttp({
  logger,
  serializers: {
    req(req) {
      return { id: req.id, method: req.method, url: req.url?.split("?")[0] };
    },
    res(res) {
      return { statusCode: res.statusCode };
    },
  },
}));

app.use(cors(corsOptions));

// Capture raw body for Crypto Pay webhook signature verification (before JSON parsing)
app.use(
  express.json({
    verify: (req: any, _res, buf) => {
      req.rawBody = buf;
    },
  })
);
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

export default app;
