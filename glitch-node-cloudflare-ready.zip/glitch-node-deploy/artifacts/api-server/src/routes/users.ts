import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getUserFromToken } from "../lib/auth";
import { formatUser } from "./auth";

const router = Router();

// GET /users/:userId
router.get("/users/:userId", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const userId = parseInt(req.params.userId, 10);
  if (isNaN(userId)) return res.status(400).json({ error: "Invalid user ID" });

  const [found] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, userId))
    .limit(1);

  if (!found) return res.status(404).json({ error: "User not found" });
  return res.json(formatUser(found));
});

// POST /user/wallet
// Sets or updates payout wallet address. Triggers 48-hour withdrawal security lockout.
router.post("/user/wallet", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const { walletAddress, network } = req.body as { walletAddress?: string; network?: string };

  if (!walletAddress || walletAddress.trim().length < 10) {
    return res.status(400).json({ error: "Invalid wallet address — must be at least 10 characters." });
  }

  const validNetworks = ["TON", "TRX", "ETH", "BSC"];
  if (!network || !validNetworks.includes(network)) {
    return res.status(400).json({ error: `Invalid network. Must be one of: ${validNetworks.join(", ")}` });
  }

  const now = new Date();

  const [updated] = await db
    .update(usersTable)
    .set({
      walletAddress: walletAddress.trim(),
      walletUpdatedAt: now,
      updatedAt: now,
    })
    .where(eq(usersTable.id, user.id))
    .returning();

  if (!updated) return res.status(500).json({ error: "Failed to update wallet" });

  return res.json(formatUser(updated));
});

export default router;
