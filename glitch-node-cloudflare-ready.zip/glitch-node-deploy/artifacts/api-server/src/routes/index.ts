import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import investRouter from "./invest";
import withdrawalsRouter from "./withdrawals";
import transactionsRouter from "./transactions";
import referralsRouter from "./referrals";
import dashboardRouter from "./dashboard";
import paymentsRouter from "./payments";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(investRouter);
router.use(withdrawalsRouter);
router.use(transactionsRouter);
router.use(referralsRouter);
router.use(dashboardRouter);
router.use(paymentsRouter);

export default router;
