import { Router } from "express";
import { db, packagesTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, and, sql, gt } from "drizzle-orm";
import { getUserFromToken } from "../lib/auth";
import { VALID_PACKAGE_AMOUNTS, PACKAGE_LIFESPAN_DAYS } from "@workspace/db";

const router = Router();

const REFERRAL_BONUS_RATE = 0.05;

// ─── GET /invest/status ───────────────────────────────────────────────────────
router.get("/invest/status", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const now = new Date();
  const packages = await db
    .select()
    .from(packagesTable)
    .where(eq(packagesTable.userId, user.id))
    .orderBy(sql`created_at DESC`);

  const activePackages = packages.filter((p) => p.isActive && p.expiresAt > now);
  const activePrincipal = activePackages.reduce((sum, p) => sum + parseFloat(p.amount), 0);
  const canClick = !user.nextAllowedClickAt || user.nextAllowedClickAt <= now;
  const clickRewardPreview = (activePrincipal * 0.01).toFixed(8);

  return res.json({
    canClick,
    activePrincipal: activePrincipal.toFixed(8),
    nextAllowedClickAt: user.nextAllowedClickAt?.toISOString() ?? null,
    clickRewardPreview,
    activePackages: activePackages.length,
    totalPackages: packages.length,
    packages: packages.map(formatPackage),
  });
});

// ─── POST /invest/purchase ────────────────────────────────────────────────────
router.post("/invest/purchase", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const { amount } = req.body as { amount: unknown };
  const amountNum = Number(amount);

  if (!VALID_PACKAGE_AMOUNTS.includes(amountNum as (typeof VALID_PACKAGE_AMOUNTS)[number])) {
    return res.status(400).json({
      error: `Invalid package amount. Valid amounts are: ${VALID_PACKAGE_AMOUNTS.join(", ")} GEL`,
    });
  }

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + PACKAGE_LIFESPAN_DAYS);

  const pkg = await db.transaction(async (tx) => {
    const [lockedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, user.id))
      .for("update")
      .limit(1);
    if (!lockedUser) throw new Error("User not found");

    const [inserted] = await tx
      .insert(packagesTable)
      .values({
        userId: user.id,
        amount: String(amountNum),
        type: "PRIMARY",
        isActive: true,
        expiresAt,
      })
      .returning();

    await tx
      .update(usersTable)
      .set({
        activePrincipal: sql`${usersTable.activePrincipal} + ${String(amountNum)}::numeric`,
        totalPrincipal: sql`${usersTable.totalPrincipal} + ${String(amountNum)}::numeric`,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, user.id));

    await tx.insert(transactionsTable).values({
      userId: user.id,
      type: "deposit",
      amount: String(amountNum),
      feeAmount: "0",
      netAmount: String(amountNum),
      status: "completed",
      description: `Package purchase — ${amountNum} GEL (PRIMARY, 180-day lifespan, non-refundable)`,
      metadata: { packageId: inserted.id, packageType: "PRIMARY" },
    });

    return inserted;
  });

  return res.status(201).json(formatPackage(pkg));
});

// ─── POST /invest/click ───────────────────────────────────────────────────────
router.post("/invest/click", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const result = await db.transaction(async (tx) => {
    const [lockedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, user.id))
      .for("update")
      .limit(1);
    if (!lockedUser) throw new Error("User not found");

    const now = new Date();

    if (lockedUser.nextAllowedClickAt && lockedUser.nextAllowedClickAt > now) {
      throw Object.assign(
        new Error(`Click locked until ${lockedUser.nextAllowedClickAt.toISOString()}`),
        { status: 400, lockedUntil: lockedUser.nextAllowedClickAt.toISOString() }
      );
    }

    const activePackages = await tx
      .select()
      .from(packagesTable)
      .where(and(eq(packagesTable.userId, lockedUser.id), eq(packagesTable.isActive, true), gt(packagesTable.expiresAt, now)));

    const activePrincipal = activePackages.reduce((sum, p) => sum + parseFloat(p.amount), 0);

    if (activePrincipal <= 0) {
      throw Object.assign(
        new Error("No active principal. Purchase a package first."),
        { status: 400 }
      );
    }

    const reward = activePrincipal * 0.01;
    const rewardStr = reward.toFixed(8);
    const nextAllowedClickAt = new Date(now.getTime() + 6 * 60 * 60 * 1000);

    await tx
      .update(usersTable)
      .set({
        availableBalance: sql`${usersTable.availableBalance} + ${rewardStr}::numeric`,
        totalEarnings: sql`${usersTable.totalEarnings} + ${rewardStr}::numeric`,
        lastClickAt: now,
        nextAllowedClickAt,
        updatedAt: now,
      })
      .where(eq(usersTable.id, lockedUser.id));

    await tx.insert(transactionsTable).values({
      userId: lockedUser.id,
      type: "earning",
      amount: rewardStr,
      feeAmount: "0",
      netAmount: rewardStr,
      status: "completed",
      description: `Click yield — 1% of ${activePrincipal.toFixed(2)} GEL active principal`,
      metadata: { activePrincipal: activePrincipal.toFixed(8) },
    });

    if (lockedUser.referredById) {
      const [referrer] = await tx
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, lockedUser.referredById))
        .for("update")
        .limit(1);

      if (referrer && referrer.nextAllowedClickAt && referrer.nextAllowedClickAt > now) {
        const referralBonus = (reward * REFERRAL_BONUS_RATE).toFixed(8);
        await tx
          .update(usersTable)
          .set({
            availableBalance: sql`${usersTable.availableBalance} + ${referralBonus}::numeric`,
            totalEarnings: sql`${usersTable.totalEarnings} + ${referralBonus}::numeric`,
            updatedAt: now,
          })
          .where(eq(usersTable.id, referrer.id));

        await tx.insert(transactionsTable).values({
          userId: referrer.id,
          type: "referral_bonus",
          amount: referralBonus,
          feeAmount: "0",
          netAmount: referralBonus,
          status: "completed",
          description: `Referral yield bonus from user #${lockedUser.id}`,
          metadata: { referredUserId: lockedUser.id, sourceReward: rewardStr },
        });
      }
    }

    const [updatedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, lockedUser.id))
      .limit(1);

    return {
      reward: rewardStr,
      newBalance: updatedUser.availableBalance,
      activePrincipal: activePrincipal.toFixed(8),
      nextAllowedClickAt: nextAllowedClickAt.toISOString(),
    };
  });

  return res.json(result);
});

// ─── POST /invest/compound ────────────────────────────────────────────────────
router.post("/invest/compound", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const { amount } = req.body as { amount: unknown };
  const amountNum = Number(amount);

  if (!VALID_PACKAGE_AMOUNTS.includes(amountNum as (typeof VALID_PACKAGE_AMOUNTS)[number])) {
    return res.status(400).json({
      error: `Invalid compound amount. Valid amounts are: ${VALID_PACKAGE_AMOUNTS.join(", ")} GEL`,
    });
  }

  const result = await db.transaction(async (tx) => {
    const [lockedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, user.id))
      .for("update")
      .limit(1);
    if (!lockedUser) throw new Error("User not found");

    if (parseFloat(lockedUser.availableBalance) < amountNum) {
      throw Object.assign(
        new Error(`Insufficient earnings balance. Available: ${lockedUser.availableBalance} GEL`),
        { status: 400 }
      );
    }

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + PACKAGE_LIFESPAN_DAYS);

    await tx
      .update(usersTable)
      .set({
        availableBalance: sql`${usersTable.availableBalance} - ${String(amountNum)}::numeric`,
        activePrincipal: sql`${usersTable.activePrincipal} + ${String(amountNum)}::numeric`,
        totalPrincipal: sql`${usersTable.totalPrincipal} + ${String(amountNum)}::numeric`,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, lockedUser.id));

    const [pkg] = await tx
      .insert(packagesTable)
      .values({
        userId: lockedUser.id,
        amount: String(amountNum),
        type: "COMPOUND",
        isActive: true,
        expiresAt,
      })
      .returning();

    await tx.insert(transactionsTable).values({
      userId: lockedUser.id,
      type: "compound",
      amount: `-${String(amountNum)}`,
      feeAmount: "0",
      netAmount: `-${String(amountNum)}`,
      status: "completed",
      description: `Compound reinvestment — ${amountNum} GEL locked as new sub-package (0% fee, 180-day)`,
      metadata: { packageId: pkg.id },
    });

    const [updatedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, lockedUser.id))
      .limit(1);

    return {
      package: formatPackage(pkg),
      newBalance: updatedUser.availableBalance,
      newActivePrincipal: updatedUser.activePrincipal,
    };
  });

  return res.json(result);
});

// ─── GET /invest/packages ─────────────────────────────────────────────────────
router.get("/invest/packages", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const packages = await db
    .select()
    .from(packagesTable)
    .where(eq(packagesTable.userId, user.id))
    .orderBy(sql`created_at DESC`);

  return res.json(packages.map(formatPackage));
});

function formatPackage(p: typeof packagesTable.$inferSelect) {
  const now = new Date();
  const msRemaining = p.expiresAt.getTime() - now.getTime();
  const daysRemaining = Math.max(0, Math.ceil(msRemaining / (1000 * 60 * 60 * 24)));
  return {
    id: p.id,
    userId: p.userId,
    amount: p.amount,
    type: p.type,
    isActive: p.isActive && p.expiresAt > now,
    createdAt: p.createdAt.toISOString(),
    expiresAt: p.expiresAt.toISOString(),
    daysRemaining,
  };
}

export default router;
