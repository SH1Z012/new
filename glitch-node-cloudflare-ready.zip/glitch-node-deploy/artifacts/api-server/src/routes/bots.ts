import { Router } from "express";

// NOTE: The "bots" concept was superseded by the investment packages system.
// Package management is handled via /invest/* routes.
// This stub is kept to avoid import errors if referenced.
const router = Router();

export default router;
