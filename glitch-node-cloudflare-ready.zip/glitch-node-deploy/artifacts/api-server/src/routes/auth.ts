import { Router } from "express";
import bcrypt from "bcryptjs";
import { db, usersTable } from "@workspace/db";
import { eq, or } from "drizzle-orm";
import { verifyTelegramInitData, generateReferralCode, generateToken, getUserFromToken } from "../lib/auth";
import { TelegramAuthBody } from "@workspace/api-zod";

const router = Router();

const BCRYPT_ROUNDS = 12;

// ─── POST /auth/telegram ──────────────────────────────────────────────────────
router.post("/auth/telegram", async (req, res) => {
  const parse = TelegramAuthBody.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ error: "Invalid request body" });

  const { initData, referralCode } = parse.data;
  let telegramUser: { id: number; username?: string; first_name?: string; last_name?: string; photo_url?: string } | null = null;

  const botToken = process.env["TELEGRAM_BOT_TOKEN"] ?? "";
  if (initData === "mock" || !botToken) {
    telegramUser = { id: 999999, username: "dev_user", first_name: "Dev", last_name: "User" };
  } else {
    telegramUser = verifyTelegramInitData(initData, botToken);
    if (!telegramUser) return res.status(401).json({ error: "Invalid Telegram initData" });
  }

  let [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.telegramId, String(telegramUser.id)))
    .limit(1);

  if (!user) {
    let referredById: number | undefined;
    if (referralCode) {
      const [referrer] = await db
        .select({ id: usersTable.id })
        .from(usersTable)
        .where(eq(usersTable.referralCode, referralCode))
        .limit(1);
      referredById = referrer?.id;
    }
    const [inserted] = await db
      .insert(usersTable)
      .values({
        telegramId: String(telegramUser.id),
        username: telegramUser.username ?? null,
        firstName: telegramUser.first_name ?? null,
        lastName: telegramUser.last_name ?? null,
        avatarUrl: telegramUser.photo_url ?? null,
        referralCode: generateReferralCode(),
        referredById: referredById ?? null,
      })
      .returning();
    user = inserted;
  }

  return res.json({ user: formatUser(user), token: generateToken(user.id) });
});

// ─── POST /auth/register ──────────────────────────────────────────────────────
// Email + password registration (browser access)
router.post("/auth/register", async (req, res) => {
  const { email, password, firstName, lastName, referralCode } = req.body as {
    email?: string;
    password?: string;
    firstName?: string;
    lastName?: string;
    referralCode?: string;
  };

  // ── Validate inputs ────────────────────────────────────────────────────────
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
    return res.status(400).json({ error: "A valid email address is required." });
  }
  if (!password || password.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }
  if (!firstName?.trim()) {
    return res.status(400).json({ error: "First name is required." });
  }
  if (!lastName?.trim()) {
    return res.status(400).json({ error: "Last name is required." });
  }

  const cleanEmail = email.trim().toLowerCase();

  // ── Duplicate check ────────────────────────────────────────────────────────
  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, cleanEmail))
    .limit(1);

  if (existing) {
    return res.status(400).json({ error: "Email already registered. Please log in instead." });
  }

  // ── Hash password ──────────────────────────────────────────────────────────
  const passwordHash = await bcrypt.hash(password, BCRYPT_ROUNDS);

  // ── Resolve referral ───────────────────────────────────────────────────────
  let referredById: number | undefined;
  if (referralCode?.trim()) {
    const [referrer] = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(eq(usersTable.referralCode, referralCode.trim()))
      .limit(1);
    referredById = referrer?.id;
  }

  // ── Create user ────────────────────────────────────────────────────────────
  // telegramId uses email-based namespace to keep uniqueness constraint satisfied
  const [user] = await db
    .insert(usersTable)
    .values({
      telegramId: `email_${cleanEmail}`,
      email: cleanEmail,
      passwordHash,
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      referralCode: generateReferralCode(),
      referredById: referredById ?? null,
    })
    .returning();

  return res.json({ user: formatUser(user), token: generateToken(user.id) });
});

// ─── POST /auth/login ─────────────────────────────────────────────────────────
// Email + password login (browser access)
router.post("/auth/login", async (req, res) => {
  const { email, password } = req.body as { email?: string; password?: string };

  if (!email?.trim()) {
    return res.status(400).json({ error: "Email is required." });
  }
  if (!password) {
    return res.status(400).json({ error: "Password is required." });
  }

  const cleanEmail = email.trim().toLowerCase();

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, cleanEmail))
    .limit(1);

  if (!user || !user.passwordHash) {
    // Deliberately vague — do not reveal whether email exists
    return res.status(401).json({ error: "Invalid email or password." });
  }

  const match = await bcrypt.compare(password, user.passwordHash);
  if (!match) {
    return res.status(401).json({ error: "Invalid email or password." });
  }

  return res.json({ user: formatUser(user), token: generateToken(user.id) });
});

// ─── GET /auth/me ─────────────────────────────────────────────────────────────
router.get("/auth/me", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });
  return res.json(formatUser(user));
});

export function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    telegramId: user.telegramId,
    username: user.username,
    firstName: user.firstName,
    lastName: user.lastName,
    avatarUrl: user.avatarUrl,
    availableBalance: user.availableBalance,
    activePrincipal: user.activePrincipal,
    totalEarnings: user.totalEarnings,
    totalPrincipal: user.totalPrincipal,
    lastClickAt: user.lastClickAt?.toISOString() ?? null,
    nextAllowedClickAt: user.nextAllowedClickAt?.toISOString() ?? null,
    lastWithdrawalAt: user.lastWithdrawalAt?.toISOString() ?? null,
    walletAddress: user.walletAddress ?? null,
    walletUpdatedAt: user.walletUpdatedAt?.toISOString() ?? null,
    referralCode: user.referralCode,
    createdAt: user.createdAt.toISOString(),
  };
}

export default router;
