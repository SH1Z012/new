import { Router } from "express";
import { db, packagesTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { VALID_PACKAGE_AMOUNTS, PACKAGE_LIFESPAN_DAYS } from "@workspace/db";
import crypto from "crypto";
import { getUserFromToken } from "../lib/auth";

const router = Router();

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getCryptoPayToken(): string {
  const token = process.env["CRYPTO_PAY_API_TOKEN"];
  if (!token) throw new Error("CRYPTO_PAY_API_TOKEN is not set");
  return token;
}

function getCryptoPayBaseUrl(): string {
  return process.env["CRYPTO_PAY_API_URL"] ?? "https://pay.crypt.bot/api";
}

// Fixed exchange rate: 1 GEL → USDT. Overrideable via CRYPTO_PAY_GEL_RATE env var.
function gelToUsdt(amountGel: number): string {
  const rate = parseFloat(process.env["CRYPTO_PAY_GEL_RATE"] ?? "0.37");
  return (amountGel * rate).toFixed(2);
}

// Crypto Pay webhook signature: HMAC-SHA256(rawBody, sha256(apiToken))
// Reference: https://help.crypt.bot/crypto-pay-api#verifying-webhook-requests
function verifyCryptoPaySignature(rawBody: Buffer, signature: string, apiToken: string): boolean {
  const secret = crypto.createHash("sha256").update(apiToken).digest();
  const computed = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  if (computed.length !== signature.length) return false;
  return crypto.timingSafeEqual(Buffer.from(computed, "hex"), Buffer.from(signature, "hex"));
}

// Call the Crypto Pay REST API
async function cryptoPayRequest(method: string, body: Record<string, unknown>): Promise<any> {
  const apiToken = getCryptoPayToken();
  const res = await fetch(`${getCryptoPayBaseUrl()}/${method}`, {
    method: "POST",
    headers: {
      "Crypto-Pay-API-Token": apiToken,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });
  const json = (await res.json()) as { ok: boolean; result?: any; error?: any };
  if (!json.ok) {
    throw Object.assign(
      new Error(`Crypto Pay API error: ${JSON.stringify(json.error ?? json)}`),
      { status: 502 }
    );
  }
  return json.result;
}

// ─── POST /payments/create-invoice ───────────────────────────────────────────
// Creates a Crypto Pay invoice, logs a PENDING deposit transaction, returns pay_url.
router.post("/payments/create-invoice", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const { amountGel } = req.body as { amountGel: unknown };
  const amountNum = Number(amountGel);

  if (!VALID_PACKAGE_AMOUNTS.includes(amountNum as (typeof VALID_PACKAGE_AMOUNTS)[number])) {
    return res.status(400).json({
      error: `Invalid package amount. Must be one of: ${VALID_PACKAGE_AMOUNTS.join(", ")} GEL`,
    });
  }

  const amountUsdt = gelToUsdt(amountNum);

  // Attach userId + packageTier in the invoice payload so the webhook can recover them
  const invoicePayload = JSON.stringify({ userId: user.id, packageTier: amountNum });

  // Guard: token must be set before we attempt any API call
  if (!process.env["CRYPTO_PAY_API_TOKEN"]) {
    return res.status(503).json({
      error: "Crypto Pay payments are not configured yet. Add CRYPTO_PAY_API_TOKEN in Secrets.",
    });
  }

  let invoice: any;
  try {
    invoice = await cryptoPayRequest("createInvoice", {
      asset: "USDT",
      amount: amountUsdt,
      description: `Glitch Node — ${amountNum} GEL Investment Package (180-day lifespan)`,
      payload: invoicePayload,
      paid_btn_name: "callback",
      paid_btn_url: process.env["APP_URL"] ?? "https://t.me/GlitchNodeBot",
      expires_in: 3600,
    });
  } catch (err: any) {
    return res.status(503).json({
      error: err.message ?? "Crypto Pay API unavailable. Please try again.",
    });
  }

  const invoiceId = String(invoice.invoice_id);

  // ── Log PENDING deposit transaction immediately after invoice creation ────
  await db.insert(transactionsTable).values({
    userId: user.id,
    type: "deposit",
    amount: String(amountNum),
    feeAmount: "0",
    netAmount: String(amountNum),
    status: "pending",
    description: `⏳ Awaiting Crypto Pay confirmation — ${amountNum} GEL package (invoice: ${invoiceId})`,
    metadata: { invoiceId, packageAmount: amountNum, amountUsdt },
  });

  return res.json({
    invoiceId,
    payUrl: invoice.pay_url,
    amountUsdt,
    amountGel: amountNum,
    expiresAt: invoice.expiration_date ?? null,
  });
});

// ─── POST /payments/webhook ───────────────────────────────────────────────────
// Official Crypto Pay webhook — HMAC-SHA256 verified, activates package on payment.
// This route is public (no JWT) — security is provided by the signature check alone.
router.post("/payments/webhook", async (req, res) => {
  // ── Step 1: Signature verification (403 Forbidden on any failure) ─────────
  const apiToken = process.env["CRYPTO_PAY_API_TOKEN"];
  if (apiToken) {
    const rawBody: Buffer | undefined = (req as any).rawBody;
    const signature = req.headers["crypto-pay-api-signature"] as string | undefined;

    if (!signature || !rawBody) {
      return res.status(403).json({ error: "Forbidden — missing signature header or body" });
    }
    if (!verifyCryptoPaySignature(rawBody, signature, apiToken)) {
      return res.status(403).json({ error: "Forbidden — invalid webhook signature" });
    }
  }

  // ── Step 2: Parse official Crypto Pay webhook shape ───────────────────────
  const update = req.body as {
    update_type?: string;
    payload?: {
      invoice_id?: number;
      status?: string;
      payload?: string; // JSON we attached in createInvoice
    };
  };

  // Only act on invoice_paid updates
  if (update.update_type !== "invoice_paid") {
    return res.json({ ok: true }); // acknowledge silently
  }

  const p = update.payload;
  if (!p || p.status !== "paid") {
    return res.json({ ok: true });
  }

  const invoiceId = String(p.invoice_id ?? "");

  // ── Step 3: Recover our metadata from the payload field ───────────────────
  let meta: { userId?: number; packageTier?: number } = {};
  try {
    meta = JSON.parse(p.payload ?? "{}");
  } catch {
    return res.status(400).json({ error: "Invalid invoice payload JSON" });
  }

  const { userId, packageTier } = meta;
  if (!userId || !packageTier) {
    return res.status(400).json({ error: "Invoice payload missing userId or packageTier" });
  }

  if (!VALID_PACKAGE_AMOUNTS.includes(packageTier as (typeof VALID_PACKAGE_AMOUNTS)[number])) {
    return res.status(400).json({ error: `${packageTier} GEL is not a valid package tier` });
  }

  // ── Step 4: Idempotency — skip if this invoiceId was already processed ────
  const [alreadyDone] = await db
    .select({ id: transactionsTable.id, status: transactionsTable.status })
    .from(transactionsTable)
    .where(
      sql`${transactionsTable.metadata}->>'invoiceId' = ${invoiceId}
          AND ${transactionsTable.status} = 'completed'
          AND ${transactionsTable.type} = 'deposit'`
    )
    .limit(1);

  if (alreadyDone) {
    return res.json({ ok: true, alreadyProcessed: true });
  }

  // ── Step 5: Atomic DB transaction ─────────────────────────────────────────
  await db.transaction(async (tx) => {
    // Lock user row to prevent concurrent webhook races
    const [lockedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .for("update")
      .limit(1);

    if (!lockedUser) throw new Error(`User ${userId} not found`);

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + PACKAGE_LIFESPAN_DAYS);

    // Create the activated package
    const [pkg] = await tx
      .insert(packagesTable)
      .values({
        userId: lockedUser.id,
        amount: String(packageTier),
        type: "PRIMARY",
        isActive: true,
        expiresAt,
      })
      .returning();

    // Increment user's active + total principal
    await tx
      .update(usersTable)
      .set({
        activePrincipal: sql`${usersTable.activePrincipal} + ${String(packageTier)}::numeric`,
        totalPrincipal: sql`${usersTable.totalPrincipal} + ${String(packageTier)}::numeric`,
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, lockedUser.id));

    // Flip the matching PENDING transaction → COMPLETED
    // Falls back to inserting a new completed record if no pending row exists
    const [pendingTx] = await tx
      .select({ id: transactionsTable.id })
      .from(transactionsTable)
      .where(
        sql`${transactionsTable.metadata}->>'invoiceId' = ${invoiceId}
            AND ${transactionsTable.status} = 'pending'
            AND ${transactionsTable.type} = 'deposit'`
      )
      .limit(1);

    if (pendingTx) {
      await tx
        .update(transactionsTable)
        .set({
          status: "completed",
          description: `Crypto Pay confirmed — ${packageTier} GEL PRIMARY package activated (invoice: ${invoiceId})`,
          metadata: { invoiceId, packageId: pkg.id, packageAmount: packageTier },
        })
        .where(eq(transactionsTable.id, pendingTx.id));
    } else {
      // Fallback: webhook arrived before invoice creation logged the pending tx
      await tx.insert(transactionsTable).values({
        userId: lockedUser.id,
        type: "deposit",
        amount: String(packageTier),
        feeAmount: "0",
        netAmount: String(packageTier),
        status: "completed",
        description: `Crypto Pay confirmed — ${packageTier} GEL PRIMARY package activated (invoice: ${invoiceId})`,
        metadata: { invoiceId, packageId: pkg.id, packageAmount: packageTier },
      });
    }
  });

  return res.json({ ok: true });
});

export default router;
