import { Router } from "express";
import { db, transactionsTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { getUserFromToken } from "../lib/auth";

const router = Router();

router.get("/transactions", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const typeFilter = req.query["type"] as string | undefined;
  const limit = Math.min(parseInt(String(req.query["limit"] ?? "50"), 10) || 50, 200);
  const offset = parseInt(String(req.query["offset"] ?? "0"), 10) || 0;

  let baseQuery = db
    .select()
    .from(transactionsTable)
    .where(
      typeFilter
        ? sql`${transactionsTable.userId} = ${user.id} AND ${transactionsTable.type} = ${typeFilter}`
        : eq(transactionsTable.userId, user.id)
    )
    .orderBy(sql`created_at DESC`)
    .limit(limit)
    .offset(offset);

  const rows = await baseQuery;

  return res.json(
    rows.map((t) => ({
      id: t.id,
      userId: t.userId,
      type: t.type,
      amount: t.amount,
      feeAmount: t.feeAmount ?? "0",
      netAmount: t.netAmount ?? t.amount,
      status: t.status ?? "completed",
      description: t.description,
      metadata: t.metadata,
      createdAt: t.createdAt.toISOString(),
    }))
  );
});

export default router;
