import { Router } from "express";
import { db, usersTable, packagesTable, transactionsTable, withdrawalsTable } from "@workspace/db";
import { eq, sql, and, gt } from "drizzle-orm";
import { getUserFromToken } from "../lib/auth";
import { formatUser } from "./auth";

const router = Router();

router.get("/dashboard", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const now = new Date();

  const [packages, recentTransactions, pendingWithdrawals] = await Promise.all([
    db
      .select()
      .from(packagesTable)
      .where(and(eq(packagesTable.userId, user.id), eq(packagesTable.isActive, true), gt(packagesTable.expiresAt, now))),

    db
      .select()
      .from(transactionsTable)
      .where(eq(transactionsTable.userId, user.id))
      .orderBy(sql`created_at DESC`)
      .limit(10),

    db
      .select({ id: withdrawalsTable.id })
      .from(withdrawalsTable)
      .where(and(eq(withdrawalsTable.userId, user.id), sql`status IN ('pending', 'processing')`)),
  ]);

  const activePrincipal = packages.reduce((sum, p) => sum + parseFloat(p.amount), 0);
  const canClick = !user.nextAllowedClickAt || user.nextAllowedClickAt <= now;
  const clickRewardPreview = (activePrincipal * 0.01).toFixed(8);

  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const todayEarnings = recentTransactions
    .filter((t) => t.type === "earning" && t.createdAt >= todayStart)
    .reduce((sum, t) => sum + parseFloat(t.amount), 0);

  return res.json({
    user: formatUser(user),
    investStatus: {
      canClick,
      activePrincipal: activePrincipal.toFixed(8),
      nextAllowedClickAt: user.nextAllowedClickAt?.toISOString() ?? null,
      clickRewardPreview,
      activePackages: packages.length,
      totalPackages: packages.length,
      packages: packages.map((p) => ({
        id: p.id,
        userId: p.userId,
        amount: p.amount,
        type: p.type,
        isActive: p.isActive,
        createdAt: p.createdAt.toISOString(),
        expiresAt: p.expiresAt.toISOString(),
        daysRemaining: Math.max(0, Math.ceil((p.expiresAt.getTime() - now.getTime()) / 86400000)),
      })),
    },
    todayEarnings: todayEarnings.toFixed(8),
    recentTransactions: recentTransactions.map((t) => ({
      id: t.id,
      userId: t.userId,
      type: t.type,
      amount: t.amount,
      description: t.description,
      metadata: t.metadata,
      createdAt: t.createdAt.toISOString(),
    })),
    pendingWithdrawals: pendingWithdrawals.length,
  });
});

export default router;
