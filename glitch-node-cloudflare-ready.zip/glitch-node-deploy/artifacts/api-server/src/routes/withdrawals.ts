import { Router } from "express";
import { db, withdrawalsTable, usersTable, transactionsTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { getUserFromToken } from "../lib/auth";
import crypto from "crypto";

const MIN_WITHDRAWAL_GEL = 10;
const WALLET_LOCKOUT_HOURS = 48;

function calculateFee(lastWithdrawalAt: Date | null): { percent: number; label: string } {
  if (!lastWithdrawalAt) return { percent: 1, label: "> 7 days" };
  const hoursSince = (Date.now() - lastWithdrawalAt.getTime()) / (1000 * 60 * 60);
  if (hoursSince < 24) return { percent: 5, label: "< 24 hours" };
  if (hoursSince < 24 * 7) return { percent: 3, label: "1 – 7 days" };
  return { percent: 1, label: "> 7 days" };
}

const router = Router();

// GET /withdrawals
router.get("/withdrawals", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const rows = await db
    .select()
    .from(withdrawalsTable)
    .where(eq(withdrawalsTable.userId, user.id))
    .orderBy(sql`created_at DESC`);

  return res.json(rows.map(formatWithdrawal));
});

// GET /withdrawals/fee-preview
// Now also returns wallet lockout status
router.get("/withdrawals/fee-preview", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const fee = calculateFee(user.lastWithdrawalAt);

  let walletLockoutUntil: string | null = null;
  if (user.walletUpdatedAt) {
    const lockoutEnd = new Date(user.walletUpdatedAt.getTime() + WALLET_LOCKOUT_HOURS * 60 * 60 * 1000);
    if (lockoutEnd > new Date()) {
      walletLockoutUntil = lockoutEnd.toISOString();
    }
  }

  return res.json({
    feePercent: fee.percent,
    feeLabel: fee.label,
    lastWithdrawalAt: user.lastWithdrawalAt?.toISOString() ?? null,
    walletLockoutUntil,
  });
});

// POST /withdrawals/request
// Blocked for 48h after wallet address update (security lockout)
router.post("/withdrawals/request", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const { amount, walletAddress, network } = req.body as {
    amount: string;
    walletAddress: string;
    network: string;
  };

  const amountNum = parseFloat(amount);
  if (isNaN(amountNum) || amountNum <= 0) {
    return res.status(400).json({ error: "Invalid amount" });
  }
  if (amountNum < MIN_WITHDRAWAL_GEL) {
    return res.status(400).json({ error: `Minimum withdrawal is ${MIN_WITHDRAWAL_GEL} GEL` });
  }
  if (!["TON", "TRX", "ETH", "BSC"].includes(network)) {
    return res.status(400).json({ error: "Invalid network" });
  }
  if (!walletAddress || walletAddress.length < 10) {
    return res.status(400).json({ error: "Invalid wallet address" });
  }

  // 48-hour wallet security lockout check (re-check from DB for freshness)
  const [freshUser] = await db
    .select({ walletUpdatedAt: usersTable.walletUpdatedAt })
    .from(usersTable)
    .where(eq(usersTable.id, user.id))
    .limit(1);

  if (freshUser?.walletUpdatedAt) {
    const lockoutEnd = new Date(freshUser.walletUpdatedAt.getTime() + WALLET_LOCKOUT_HOURS * 60 * 60 * 1000);
    if (lockoutEnd > new Date()) {
      const remaining = Math.ceil((lockoutEnd.getTime() - Date.now()) / (1000 * 60 * 60));
      return res.status(400).json({
        error: `Security Lockout: You cannot withdraw funds within 48 hours of updating your wallet address. Withdrawals unlock in approximately ${remaining} hour${remaining !== 1 ? "s" : ""}.`,
        lockoutUntil: lockoutEnd.toISOString(),
      });
    }
  }

  const withdrawal = await db.transaction(async (tx) => {
    const [lockedUser] = await tx
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, user.id))
      .for("update")
      .limit(1);
    if (!lockedUser) throw new Error("User not found");

    const available = parseFloat(lockedUser.availableBalance);
    if (amountNum > available) {
      throw Object.assign(
        new Error(`Insufficient earnings. Available: ${lockedUser.availableBalance} GEL. Principal cannot be withdrawn.`),
        { status: 400 }
      );
    }

    const fee = calculateFee(lockedUser.lastWithdrawalAt);
    const feeAmount = (amountNum * fee.percent) / 100;
    const netAmount = amountNum - feeAmount;

    await tx
      .update(usersTable)
      .set({
        availableBalance: sql`${usersTable.availableBalance} - ${amount}::numeric`,
        lastWithdrawalAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(usersTable.id, lockedUser.id));

    const [w] = await tx
      .insert(withdrawalsTable)
      .values({
        userId: lockedUser.id,
        amount,
        feeAmount: feeAmount.toFixed(8),
        feePercent: fee.percent,
        netAmount: netAmount.toFixed(8),
        walletAddress,
        network: network as "TON" | "TRX" | "ETH" | "BSC",
        status: "pending",
      })
      .returning();

    await tx.insert(transactionsTable).values({
      userId: lockedUser.id,
      type: "withdrawal",
      amount: `-${amount}`,
      feeAmount: feeAmount.toFixed(8),
      netAmount: `-${netAmount.toFixed(8)}`,
      status: "pending",
      description: `Withdrawal — ${amountNum} GEL (fee: ${fee.percent}%, net: ${netAmount.toFixed(2)} GEL) to ${walletAddress} [${network}]`,
      metadata: { withdrawalId: w.id, feePercent: fee.percent, feeAmount: feeAmount.toFixed(8), netAmount: netAmount.toFixed(8) },
    });

    return w;
  });

  return res.status(201).json(formatWithdrawal(withdrawal));
});

// GET /withdrawals/:withdrawalId
router.get("/withdrawals/:withdrawalId", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const withdrawalId = parseInt(req.params.withdrawalId, 10);
  if (isNaN(withdrawalId)) return res.status(400).json({ error: "Invalid ID" });

  const [w] = await db
    .select()
    .from(withdrawalsTable)
    .where(and(eq(withdrawalsTable.id, withdrawalId), eq(withdrawalsTable.userId, user.id)))
    .limit(1);

  if (!w) return res.status(404).json({ error: "Withdrawal not found" });
  return res.json(formatWithdrawal(w));
});

// POST /withdrawals/:withdrawalId/webhook
router.post("/withdrawals/:withdrawalId/webhook", async (req, res) => {
  const withdrawalId = parseInt(req.params.withdrawalId, 10);
  if (isNaN(withdrawalId)) return res.status(400).json({ error: "Invalid ID" });

  const { event, paymentId, signature } = req.body as {
    event: string;
    paymentId: string;
    signature: string;
  };

  const webhookSecret = process.env["CRYPTO_PAY_WEBHOOK_SECRET"] ?? "";
  if (webhookSecret) {
    const expectedSig = crypto
      .createHmac("sha256", webhookSecret)
      .update(JSON.stringify({ event, paymentId }))
      .digest("hex");
    if (expectedSig !== signature) {
      return res.status(400).json({ error: "Invalid webhook signature" });
    }
  }

  if (event === "payment.completed") {
    await db
      .update(withdrawalsTable)
      .set({ status: "completed", completedAt: new Date(), txHash: paymentId })
      .where(eq(withdrawalsTable.id, withdrawalId));

    await db
      .update(transactionsTable)
      .set({ status: "completed" })
      .where(sql`${transactionsTable.metadata}->>'withdrawalId' = ${String(withdrawalId)} AND ${transactionsTable.type} = 'withdrawal'`);
  } else if (event === "payment.failed") {
    await db.transaction(async (tx) => {
      const [w] = await tx
        .select()
        .from(withdrawalsTable)
        .where(eq(withdrawalsTable.id, withdrawalId))
        .for("update")
        .limit(1);

      if (w && (w.status === "pending" || w.status === "processing")) {
        await tx
          .update(withdrawalsTable)
          .set({ status: "failed" })
          .where(eq(withdrawalsTable.id, w.id));

        await tx
          .update(usersTable)
          .set({
            availableBalance: sql`${usersTable.availableBalance} + ${w.amount}::numeric`,
            updatedAt: new Date(),
          })
          .where(eq(usersTable.id, w.userId));

        await tx
          .update(transactionsTable)
          .set({ status: "failed" })
          .where(sql`${transactionsTable.metadata}->>'withdrawalId' = ${String(withdrawalId)} AND ${transactionsTable.type} = 'withdrawal'`);
      }
    });
  }

  return res.json({ ok: true });
});

function formatWithdrawal(w: typeof withdrawalsTable.$inferSelect) {
  return {
    id: w.id,
    userId: w.userId,
    amount: w.amount,
    feeAmount: w.feeAmount ?? "0",
    feePercent: w.feePercent ?? 1,
    netAmount: w.netAmount ?? w.amount,
    walletAddress: w.walletAddress,
    network: w.network,
    status: w.status,
    txHash: w.txHash,
    createdAt: w.createdAt.toISOString(),
    completedAt: w.completedAt?.toISOString() ?? null,
  };
}

export default router;
