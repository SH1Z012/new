import { Router } from "express";
import { db, usersTable, transactionsTable, packagesTable } from "@workspace/db";
import { eq, sql, gt } from "drizzle-orm";
import { getUserFromToken } from "../lib/auth";

const router = Router();

router.get("/referrals", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });

  const now = new Date();

  const referrals = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.referredById, user.id));

  const referralIds = referrals.map((r) => r.id);
  const deployedUserIds = new Set<number>();
  const currentlyClickingIds = new Set<number>();

  if (referralIds.length > 0) {
    // Friends with active packages
    const pkgs = await db
      .select({ userId: packagesTable.userId })
      .from(packagesTable)
      .where(
        sql`${packagesTable.userId} = ANY(ARRAY[${sql.join(referralIds.map((id) => sql`${id}`), sql`, `)}]::int[]) AND ${packagesTable.isActive} = true AND ${packagesTable.expiresAt} > NOW()`
      );
    pkgs.forEach((p) => deployedUserIds.add(p.userId));

    // Friends whose 6h click timer is actively running RIGHT NOW (anti-fraud synced)
    const clickers = await db
      .select({ id: usersTable.id })
      .from(usersTable)
      .where(
        sql`${usersTable.id} = ANY(ARRAY[${sql.join(referralIds.map((id) => sql`${id}`), sql`, `)}]::int[]) AND ${usersTable.nextAllowedClickAt} > NOW()`
      );
    clickers.forEach((c) => currentlyClickingIds.add(c.id));
  }

  const bonusRows = await db
    .select({ amount: transactionsTable.amount })
    .from(transactionsTable)
    .where(
      sql`${transactionsTable.userId} = ${user.id} AND ${transactionsTable.type} = 'referral_bonus'`
    );

  const totalBonusEarned = bonusRows
    .reduce((sum, r) => sum + parseFloat(r.amount), 0)
    .toFixed(8);

  const baseUrl = process.env["APP_URL"] ?? "https://t.me/GlitchNodeBot";
  const referralLink = `${baseUrl}?start=${user.referralCode}`;
  const activeCount = referrals.filter((r) => deployedUserIds.has(r.id)).length;
  const currentlyClickingCount = currentlyClickingIds.size;

  return res.json({
    referralCode: user.referralCode,
    referralLink,
    totalReferrals: referrals.length,
    activeReferrals: activeCount,
    currentlyClicking: currentlyClickingCount,
    pendingBonus: "0",
    totalBonusEarned,
    referrals: referrals.map((r) => ({
      id: r.id,
      username: r.username,
      firstName: r.firstName,
      joinedAt: r.createdAt.toISOString(),
      hasDeployed: deployedUserIds.has(r.id),
      isCurrentlyClicking: currentlyClickingIds.has(r.id),
      bonusEarned: bonusRows.length > 0 ? (parseFloat(totalBonusEarned) / referrals.length).toFixed(8) : "0.00000000",
    })),
  });
});

router.post("/referrals/claim", async (req, res) => {
  const user = await getUserFromToken(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Not authenticated" });
  return res.status(400).json({ error: "No pending bonuses to claim" });
});

export default router;
