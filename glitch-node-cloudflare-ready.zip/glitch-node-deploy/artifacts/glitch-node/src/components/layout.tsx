import { Link, useLocation } from "wouter";
import { LayoutDashboard, Package, Layers, Wallet, Users, Settings, LogOut } from "lucide-react";
import { useAuth } from "@/context/auth";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { logout, user } = useAuth();
  const queryClient = useQueryClient();
  const [showLogout, setShowLogout] = useState(false);

  const handleLogout = () => {
    queryClient.clear();
    logout();
  };

  const displayName = user?.firstName
    ? user.firstName
    : user?.username
    ? `@${user.username}`
    : "USER";

  return (
    <div className="mx-auto w-full max-w-[375px] min-h-[100dvh] flex flex-col bg-background relative border-x border-border shadow-2xl overflow-hidden">
      {/* Background Grid */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          backgroundImage:
            "linear-gradient(hsl(var(--primary)/0.2) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary)/0.2) 1px, transparent 1px)",
          backgroundSize: "20px 20px",
        }}
      />
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />

      {/* Top header strip */}
      <div className="relative z-20 flex items-center justify-between px-4 py-2 border-b border-border/50 bg-card/40 backdrop-blur-sm">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[9px] text-primary font-mono uppercase tracking-widest">GLITCH NODE</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-[9px] text-muted-foreground font-mono uppercase truncate max-w-[100px]">{displayName}</span>
          <button
            onClick={() => setShowLogout(true)}
            data-testid="button-logout"
            className="flex items-center gap-1 text-[9px] text-muted-foreground font-mono uppercase hover:text-destructive transition-colors px-1.5 py-1 border border-transparent hover:border-destructive/30"
            title="გამოსვლა (Logout)"
          >
            <LogOut size={11} />
            <span className="hidden xs:inline">გამოსვლა</span>
          </button>
        </div>
      </div>

      {/* Logout confirmation modal */}
      {showLogout && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm">
          <div className="mx-4 border border-destructive/40 bg-card p-6 flex flex-col gap-4 shadow-[0_0_40px_rgba(255,0,0,0.1)]">
            <div className="flex items-center gap-2">
              <LogOut size={16} className="text-destructive" />
              <h2 className="text-sm font-bold font-mono uppercase tracking-widest text-foreground">Confirm Logout</h2>
            </div>
            <p className="text-[11px] text-muted-foreground font-mono leading-relaxed">
              გამოსვლა — Your session will be terminated. You will need to log in again to access your account.
            </p>
            <div className="flex gap-2">
              <button
                onClick={() => setShowLogout(false)}
                className="flex-1 py-2.5 border border-border bg-background text-foreground font-mono font-bold uppercase text-xs tracking-widest hover:border-primary/30 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleLogout}
                data-testid="button-logout-confirm"
                className="flex-1 py-2.5 bg-destructive text-destructive-foreground font-mono font-bold uppercase text-xs tracking-widest hover:bg-destructive/80 transition-colors flex items-center justify-center gap-1.5"
              >
                <LogOut size={12} /> გამოსვლა
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto pb-[70px] relative z-10">
        {children}
      </div>

      {/* Bottom nav — 6 items */}
      <div className="absolute bottom-0 left-0 right-0 h-[70px] bg-card border-t border-border flex items-center justify-around px-1 z-20 shadow-[0_-4px_20px_rgba(0,255,255,0.05)]">
        <NavItem href="/" icon={<LayoutDashboard size={17} />} label="Dash" active={location === "/"} />
        <NavItem href="/plans" icon={<Package size={17} />} label="Invest" active={location === "/plans"} />
        <NavItem href="/bots" icon={<Layers size={17} />} label="Packages" active={location === "/bots"} />
        <NavItem href="/withdraw" icon={<Wallet size={17} />} label="Withdraw" active={location === "/withdraw"} />
        <NavItem href="/invite" icon={<Users size={17} />} label="Invite" active={location === "/invite"} />
        <NavItem href="/profile" icon={<Settings size={17} />} label="Profile" active={location === "/profile" || location === "/transactions"} />
      </div>
    </div>
  );
}

function NavItem({
  href, icon, label, active,
}: {
  href: string;
  icon: React.ReactNode;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      href={href}
      className={`flex flex-col items-center justify-center w-14 h-full gap-1 transition-colors ${
        active
          ? "text-primary drop-shadow-[0_0_8px_rgba(0,255,255,0.8)]"
          : "text-muted-foreground hover:text-primary/70"
      }`}
    >
      {icon}
      <span className="text-[9px] font-medium uppercase tracking-wider">{label}</span>
    </Link>
  );
}
