import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";
import { AuthProvider, useAuth } from "@/context/auth";

import Dashboard from "@/pages/dashboard";
import Plans from "@/pages/plans";
import Bots from "@/pages/bots";
import Withdraw from "@/pages/withdraw";
import Invite from "@/pages/invite";
import Transactions from "@/pages/transactions";
import Profile from "@/pages/profile";
import AuthPage from "@/pages/auth";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

// Protected routes — redirects to auth gate if unauthenticated
const PROTECTED_PATHS = ["/", "/plans", "/bots", "/withdraw", "/invite", "/transactions", "/profile"];

function ProtectedRouter() {
  const { isAuthenticated } = useAuth();
  const [location] = useLocation();

  const needsAuth = PROTECTED_PATHS.some(
    (p) => location === p || location.startsWith(p + "/")
  );

  if (!isAuthenticated && needsAuth) {
    return <AuthPage />;
  }

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/plans" component={Plans} />
        <Route path="/bots" component={Bots} />
        <Route path="/withdraw" component={Withdraw} />
        <Route path="/invite" component={Invite} />
        <Route path="/transactions" component={Transactions} />
        <Route path="/profile" component={Profile} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <ProtectedRouter />
          </WouterRouter>
        </AuthProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
