import { useGetDashboard, useClickYield, getGetDashboardQueryKey, getGetMeQueryKey } from "@workspace/api-client-react";
import { useState, useEffect, useCallback } from "react";
import { Link } from "wouter";
import { ArrowRight, ArrowUpRight, ArrowDownRight, Zap, ShieldAlert, MousePointerClick, Clock, Package } from "lucide-react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

function useCountdown(targetIso: string | null) {
  const getRemaining = useCallback(() => {
    if (!targetIso) return 0;
    return Math.max(0, new Date(targetIso).getTime() - Date.now());
  }, [targetIso]);

  const [ms, setMs] = useState(getRemaining);

  useEffect(() => {
    setMs(getRemaining());
    const id = setInterval(() => setMs(getRemaining()), 1000);
    return () => clearInterval(id);
  }, [getRemaining]);

  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  return {
    ms,
    display: `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`,
    done: ms === 0,
  };
}

const TX_ICONS: Record<string, React.ReactNode> = {
  earning: <Zap size={13} />,
  deposit: <ArrowUpRight size={13} />,
  withdrawal: <ArrowDownRight size={13} />,
  referral_bonus: <ArrowUpRight size={13} />,
  compound: <Package size={13} />,
};

export default function Dashboard() {
  const { data: dashboard, isLoading } = useGetDashboard({ query: { queryKey: getGetDashboardQueryKey() } });
  const clickYield = useClickYield();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const nextClickAt = dashboard?.investStatus?.nextAllowedClickAt ?? null;
  const countdown = useCountdown(nextClickAt);
  const canClick = dashboard?.investStatus?.canClick ?? false;
  const isLocked = !canClick && !!nextClickAt;

  const handleClick = () => {
    clickYield.mutate(undefined, {
      onSuccess: (res) => {
        toast({
          title: `+${parseFloat(res.reward).toFixed(2)} GEL Earned`,
          description: `Next click available in 6 hours.`,
          className: "bg-card border-primary text-primary font-mono",
        });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      },
      onError: (err: any) => {
        toast({ title: "Click Failed", description: err?.data?.error ?? err.message ?? "Unknown error", variant: "destructive" });
      },
    });
  };

  if (isLoading || !dashboard) {
    return (
      <div className="p-4 flex flex-col gap-4 animate-pulse">
        <div className="h-8 w-40 bg-card border border-border" />
        <div className="h-40 bg-card border border-border" />
        <div className="flex gap-2"><div className="h-24 flex-1 bg-card border border-border" /><div className="h-24 flex-1 bg-card border border-border" /></div>
        <div className="h-28 bg-card border border-border" />
      </div>
    );
  }

  const { user, investStatus, todayEarnings, recentTransactions } = dashboard;

  return (
    <div className="p-4 flex flex-col gap-4 pb-8">
      {/* Header */}
      <header className="flex justify-between items-center">
        <h1 className="text-lg font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
          <ShieldAlert size={18} className="text-primary" />
          GLITCH NODE
        </h1>
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[10px] font-mono text-primary tracking-widest">ONLINE</span>
        </div>
      </header>

      {/* Balance Card */}
      <div className="border border-border bg-card p-4">
        <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-1">Available Earnings</p>
        <p className="text-4xl font-bold text-primary font-mono tracking-tighter" data-testid="text-available-balance">
          {parseFloat(user.availableBalance).toFixed(2)} <span className="text-xl text-muted-foreground">GEL</span>
        </p>
        <div className="grid grid-cols-2 gap-4 mt-4 pt-3 border-t border-border">
          <div>
            <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1 mb-0.5">
              <Package size={9} className="text-primary" /> Active Principal
            </p>
            <p className="text-base font-mono text-foreground" data-testid="text-active-principal">
              {parseFloat(user.activePrincipal).toFixed(2)} GEL
            </p>
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase flex items-center gap-1 mb-0.5">
              <ShieldAlert size={9} className="text-destructive" /> Total Locked
            </p>
            <p className="text-base font-mono text-foreground" data-testid="text-total-principal">
              {parseFloat(user.totalPrincipal).toFixed(2)} GEL
            </p>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-2 gap-3">
        <div className="border border-border bg-card p-3">
          <p className="text-[10px] text-muted-foreground uppercase mb-1">Today's Yield</p>
          <p className="text-xl font-mono text-primary flex items-center gap-1">
            <ArrowUpRight size={14} />
            {parseFloat(todayEarnings).toFixed(2)} GEL
          </p>
        </div>
        <div className="border border-border bg-card p-3">
          <p className="text-[10px] text-muted-foreground uppercase mb-1">Packages</p>
          <p className="text-xl font-mono text-foreground">{investStatus.activePackages} active</p>
        </div>
      </div>

      {/* CLICK YIELD BUTTON — core mechanic */}
      <div className="border border-primary bg-primary/5 p-4 flex flex-col gap-3">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-0.5">Manual Yield Click</p>
            <p className="text-xs text-muted-foreground">
              Reward: <span className="text-primary font-mono font-bold">+{parseFloat(investStatus.clickRewardPreview).toFixed(2)} GEL</span> (1% of {parseFloat(investStatus.activePrincipal).toFixed(2)} GEL)
            </p>
          </div>
          <div className="text-right">
            <p className="text-[10px] font-mono text-muted-foreground uppercase mb-0.5">Max 4×/day</p>
            <p className="text-[10px] text-muted-foreground">6h lock per click</p>
          </div>
        </div>

        {/* Countdown timer */}
        {isLocked && (
          <div className="flex items-center gap-2 border border-border bg-background/60 px-3 py-2">
            <Clock size={13} className="text-muted-foreground shrink-0" />
            <p className="text-[10px] text-muted-foreground uppercase font-mono">Next click in</p>
            <p className="text-primary font-mono font-bold text-sm ml-auto tracking-widest" data-testid="text-countdown">
              {countdown.display}
            </p>
          </div>
        )}

        {!isLocked && nextClickAt && countdown.done && (
          <div className="border border-primary/30 bg-primary/10 px-3 py-2 flex items-center gap-2">
            <Zap size={12} className="text-primary" />
            <p className="text-[10px] text-primary font-mono uppercase tracking-widest">Timer expired — click when ready</p>
          </div>
        )}

        <button
          onClick={handleClick}
          disabled={!canClick || clickYield.isPending || parseFloat(investStatus.activePrincipal) === 0}
          data-testid="button-click-yield"
          className="w-full py-4 font-bold font-mono uppercase tracking-widest text-sm transition-all duration-200 flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed
            bg-primary text-primary-foreground hover:bg-primary/80 disabled:bg-muted"
        >
          {clickYield.isPending ? (
            <><span className="animate-pulse">PROCESSING...</span></>
          ) : canClick && parseFloat(investStatus.activePrincipal) > 0 ? (
            <><MousePointerClick size={16} /> COLLECT YIELD</>
          ) : parseFloat(investStatus.activePrincipal) === 0 ? (
            <>NO ACTIVE PRINCIPAL — <Link href="/plans" className="underline ml-1">PURCHASE PACKAGE</Link></>
          ) : (
            <><Clock size={14} /> LOCKED — {countdown.display}</>
          )}
        </button>

        <p className="text-[9px] text-muted-foreground text-center font-mono">
          "No Click, No Time" — timer stays at 00:00:00 until you manually collect. Delay time is lost.
        </p>
      </div>

      {/* Active Packages summary */}
      {investStatus.packages && investStatus.packages.length > 0 && (
        <div>
          <div className="flex justify-between items-end mb-2">
            <h2 className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Active Packages</h2>
            <Link href="/bots" className="text-[10px] text-primary uppercase flex items-center gap-0.5">All <ArrowRight size={9} /></Link>
          </div>
          <div className="flex flex-col gap-2">
            {investStatus.packages.slice(0, 3).map((pkg) => (
              <div key={pkg.id} className="border border-border bg-card p-3 flex justify-between items-center" data-testid={`card-package-${pkg.id}`}>
                <div>
                  <p className="text-xs font-mono font-bold text-foreground">{pkg.type === "PRIMARY" ? "Primary Package" : "Compound Package"}</p>
                  <p className="text-[10px] text-muted-foreground">{pkg.daysRemaining}d remaining</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-mono text-primary">{parseFloat(pkg.amount).toFixed(2)} GEL</p>
                  <div className="flex items-center gap-1 justify-end mt-0.5">
                    <span className="w-1 h-1 rounded-full bg-primary animate-pulse" />
                    <p className="text-[9px] text-muted-foreground uppercase">{pkg.isActive ? "active" : "expired"}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Transactions */}
      <div>
        <div className="flex justify-between items-end mb-2 mt-1">
          <h2 className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">System Log</h2>
          <Link href="/transactions" className="text-[10px] text-primary uppercase flex items-center gap-0.5">Full Log <ArrowRight size={9} /></Link>
        </div>
        <div className="border border-border bg-card overflow-hidden">
          {recentTransactions.length === 0 ? (
            <div className="p-4 text-center text-xs text-muted-foreground font-mono">NO TRANSACTIONS YET</div>
          ) : (
            <div className="flex flex-col divide-y divide-border">
              {recentTransactions.slice(0, 6).map((tx) => (
                <div key={tx.id} className="p-3 flex justify-between items-center" data-testid={`row-tx-${tx.id}`}>
                  <div className="flex items-center gap-2.5">
                    <div className={`p-1.5 ${parseFloat(tx.amount) > 0 ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"}`}>
                      {TX_ICONS[tx.type] ?? <ArrowUpRight size={13} />}
                    </div>
                    <div>
                      <p className="text-[10px] font-mono uppercase text-foreground">{tx.type.replace("_", " ")}</p>
                      <p className="text-[9px] text-muted-foreground">{format(new Date(tx.createdAt), "MMM d, HH:mm")}</p>
                    </div>
                  </div>
                  <p className={`text-sm font-mono font-bold ${parseFloat(tx.amount) > 0 ? "text-primary" : "text-foreground"}`}>
                    {parseFloat(tx.amount) > 0 ? "+" : ""}{parseFloat(tx.amount).toFixed(2)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
