import { useState, useEffect } from "react";
import { useTelegramAuth, useLoginUser, useRegisterUser } from "@workspace/api-client-react";
import { useAuth, type AuthUser } from "@/context/auth";
import {
  Zap, LogIn, UserPlus, Eye, EyeOff, AlertCircle, Loader2, Shield, Mail, Lock, User,
} from "lucide-react";

type Tab = "login" | "register";

function detectTelegram(): string | null {
  try {
    const tg = (window as any).Telegram?.WebApp;
    const data = tg?.initData;
    return data && data.length > 0 ? data : null;
  } catch {
    return null;
  }
}

function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export default function AuthPage() {
  const { login } = useAuth();
  const telegramAuth = useTelegramAuth();
  const loginMutation = useLoginUser();
  const registerMutation = useRegisterUser();

  const [tab, setTab] = useState<Tab>("login");
  const [error, setError] = useState<string | null>(null);
  const [telegramAttempted, setTelegramAttempted] = useState(false);

  // ── Login state
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showLoginPw, setShowLoginPw] = useState(false);

  // ── Register state
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regFirstName, setRegFirstName] = useState("");
  const [regLastName, setRegLastName] = useState("");
  const [regReferral, setRegReferral] = useState("");
  const [showRegPw, setShowRegPw] = useState(false);

  // ── Client-side field errors
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // ── Auto-detect Telegram → silent login
  useEffect(() => {
    const initData = detectTelegram();
    if (initData && !telegramAttempted) {
      setTelegramAttempted(true);
      telegramAuth.mutate({ data: { initData } }, {
        onSuccess: (res) => login(res.token, res.user as AuthUser),
        onError: () => setError("Telegram auth failed. Please use the form below."),
      });
    }
  }, []);

  // ── Login submit
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const errs: Record<string, string> = {};
    if (!validateEmail(loginEmail)) errs.loginEmail = "Enter a valid email address.";
    if (!loginPassword) errs.loginPassword = "Password is required.";
    if (Object.keys(errs).length) { setFieldErrors(errs); return; }
    setFieldErrors({});

    loginMutation.mutate({ data: { email: loginEmail.trim().toLowerCase(), password: loginPassword } }, {
      onSuccess: (res) => login(res.token, res.user as AuthUser),
      onError: (err: any) => setError(err?.data?.error ?? err?.message ?? "Invalid email or password."),
    });
  };

  // ── Register submit
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const errs: Record<string, string> = {};
    if (!validateEmail(regEmail)) errs.regEmail = "Enter a valid email address.";
    if (regPassword.length < 6) errs.regPassword = "Password must be at least 6 characters.";
    if (!regFirstName.trim()) errs.regFirstName = "First name is required.";
    if (!regLastName.trim()) errs.regLastName = "Last name is required.";
    if (Object.keys(errs).length) { setFieldErrors(errs); return; }
    setFieldErrors({});

    registerMutation.mutate({
      data: {
        email: regEmail.trim().toLowerCase(),
        password: regPassword,
        firstName: regFirstName.trim(),
        lastName: regLastName.trim(),
        referralCode: regReferral.trim() || null,
      },
    }, {
      onSuccess: (res) => login(res.token, res.user as AuthUser),
      onError: (err: any) => setError(err?.data?.error ?? err?.message ?? "Registration failed."),
    });
  };

  // ── Full-screen Telegram spinner
  if (telegramAuth.isPending) {
    return (
      <FullScreen>
        <GlitchLogo />
        <div className="w-10 h-10 border-2 border-primary border-t-transparent rounded-none animate-spin" />
        <p className="text-primary font-mono uppercase tracking-widest text-xs animate-pulse">
          AUTHENTICATING VIA TELEGRAM...
        </p>
      </FullScreen>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col max-w-[375px] mx-auto border-x border-border relative overflow-hidden">
      <GridBg />
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/10 via-background to-background" />

      <div className="relative z-10 flex flex-col items-center justify-center flex-1 px-5 py-8 gap-5">
        <GlitchLogo />

        <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest text-center">
          Crypto-Banking Investment Terminal
        </p>

        {/* Browser-mode badge */}
        {!detectTelegram() && (
          <div className="flex items-center gap-2 border border-border/50 bg-card/30 px-3 py-1.5 text-[9px] text-muted-foreground font-mono uppercase">
            <Shield size={9} className="text-primary" />
            Browser mode · Secure email authentication
          </div>
        )}

        {/* Global error */}
        {error && (
          <div className="w-full border border-destructive/50 bg-destructive/10 px-3 py-2.5 flex items-start gap-2">
            <AlertCircle size={13} className="text-destructive shrink-0 mt-0.5" />
            <p className="text-[11px] text-destructive font-mono leading-relaxed">{error}</p>
          </div>
        )}

        {/* Tab switcher */}
        <div className="w-full grid grid-cols-2 border border-border">
          {(["login", "register"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => { setTab(t); setError(null); setFieldErrors({}); }}
              className={`py-2.5 text-xs font-mono uppercase font-bold tracking-widest transition-colors ${
                tab === t
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "login"
                ? <><LogIn size={10} className="inline mr-1" />LOGIN</>
                : <><UserPlus size={10} className="inline mr-1" />REGISTER</>}
            </button>
          ))}
        </div>

        {/* ── LOGIN FORM ─────────────────────────────────────────────── */}
        {tab === "login" && (
          <form onSubmit={handleLogin} className="w-full flex flex-col gap-3">
            <InputField
              label="Email Address"
              type="email"
              value={loginEmail}
              onChange={setLoginEmail}
              placeholder="your@email.com"
              icon={<Mail size={12} />}
              error={fieldErrors.loginEmail}
              testId="input-login-email"
              autoComplete="email"
            />
            <PasswordField
              label="Password"
              value={loginPassword}
              onChange={setLoginPassword}
              show={showLoginPw}
              onToggle={() => setShowLoginPw((v) => !v)}
              error={fieldErrors.loginPassword}
              testId="input-login-password"
              autoComplete="current-password"
            />

            <button
              type="submit"
              disabled={loginMutation.isPending}
              data-testid="button-login-submit"
              className="w-full py-3.5 bg-primary text-primary-foreground font-bold font-mono uppercase tracking-widest text-sm disabled:opacity-40 flex items-center justify-center gap-2 hover:bg-primary/80 transition-colors mt-1"
            >
              {loginMutation.isPending
                ? <><Loader2 size={14} className="animate-spin" />AUTHENTICATING...</>
                : <><LogIn size={14} />ACCESS TERMINAL</>}
            </button>

            <p className="text-center text-[10px] text-muted-foreground font-mono">
              No account?{" "}
              <button type="button" onClick={() => { setTab("register"); setError(null); setFieldErrors({}); }} className="text-primary hover:underline">
                Register here
              </button>
            </p>
          </form>
        )}

        {/* ── REGISTER FORM ──────────────────────────────────────────── */}
        {tab === "register" && (
          <form onSubmit={handleRegister} className="w-full flex flex-col gap-3">
            <div className="grid grid-cols-2 gap-2">
              <InputField
                label="First Name *"
                type="text"
                value={regFirstName}
                onChange={setRegFirstName}
                placeholder="Giorgi"
                icon={<User size={12} />}
                error={fieldErrors.regFirstName}
                testId="input-register-firstname"
                autoComplete="given-name"
              />
              <InputField
                label="Last Name *"
                type="text"
                value={regLastName}
                onChange={setRegLastName}
                placeholder="Beridze"
                icon={<User size={12} />}
                error={fieldErrors.regLastName}
                testId="input-register-lastname"
                autoComplete="family-name"
              />
            </div>

            <InputField
              label="Email Address *"
              type="email"
              value={regEmail}
              onChange={setRegEmail}
              placeholder="your@email.com"
              icon={<Mail size={12} />}
              error={fieldErrors.regEmail}
              testId="input-register-email"
              autoComplete="email"
            />

            <PasswordField
              label="Password * (min 6 chars)"
              value={regPassword}
              onChange={setRegPassword}
              show={showRegPw}
              onToggle={() => setShowRegPw((v) => !v)}
              error={fieldErrors.regPassword}
              testId="input-register-password"
              autoComplete="new-password"
            />

            <InputField
              label="Referral Code (optional)"
              type="text"
              value={regReferral}
              onChange={setRegReferral}
              placeholder="Friend's invite code"
              error={fieldErrors.regReferral}
              testId="input-register-referral"
            />

            <div className="border border-border/40 bg-card/20 px-3 py-2 text-[9px] text-muted-foreground font-mono leading-relaxed">
              By registering you acknowledge: principal deposits are permanently locked (non-refundable). Only earnings may be withdrawn.
            </div>

            <button
              type="submit"
              disabled={registerMutation.isPending}
              data-testid="button-register-submit"
              className="w-full py-3.5 bg-primary text-primary-foreground font-bold font-mono uppercase tracking-widest text-sm disabled:opacity-40 flex items-center justify-center gap-2 hover:bg-primary/80 transition-colors"
            >
              {registerMutation.isPending
                ? <><Loader2 size={14} className="animate-spin" />CREATING ACCOUNT...</>
                : <><UserPlus size={14} />CREATE ACCOUNT</>}
            </button>

            <p className="text-center text-[10px] text-muted-foreground font-mono">
              Already have an account?{" "}
              <button type="button" onClick={() => { setTab("login"); setError(null); setFieldErrors({}); }} className="text-primary hover:underline">
                Login here
              </button>
            </p>
          </form>
        )}
      </div>

      <div className="relative z-10 p-3 border-t border-border/30 text-center">
        <p className="text-[9px] text-muted-foreground font-mono uppercase tracking-widest opacity-40">
          GLITCH NODE · ENCRYPTED · v1.0
        </p>
      </div>
    </div>
  );
}

// ── Shared sub-components ────────────────────────────────────────────────────

function GlitchLogo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="w-10 h-10 border border-primary flex items-center justify-center bg-primary/10 shadow-[0_0_20px_rgba(0,255,255,0.2)]">
        <Zap size={22} className="text-primary" />
      </div>
      <div>
        <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest leading-none">
          GLITCH <span className="text-primary">NODE</span>
        </h1>
        <div className="flex items-center gap-1 mt-0.5">
          <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
          <span className="text-[9px] text-primary font-mono uppercase tracking-widest">ONLINE</span>
        </div>
      </div>
    </div>
  );
}

function GridBg() {
  return (
    <div
      className="absolute inset-0 pointer-events-none opacity-20"
      style={{
        backgroundImage:
          "linear-gradient(hsl(var(--primary)/0.2) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--primary)/0.2) 1px, transparent 1px)",
        backgroundSize: "20px 20px",
      }}
    />
  );
}

function FullScreen({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-[100dvh] bg-background flex flex-col items-center justify-center max-w-[375px] mx-auto border-x border-border relative">
      <GridBg />
      <div className="relative z-10 flex flex-col items-center gap-4">{children}</div>
    </div>
  );
}

function InputField({
  label, type, value, onChange, placeholder, icon, error, testId, autoComplete,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  icon?: React.ReactNode;
  error?: string;
  testId?: string;
  autoComplete?: string;
}) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[9px] text-muted-foreground font-mono uppercase tracking-widest">{label}</label>
      <div className="relative">
        {icon && (
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none">
            {icon}
          </span>
        )}
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          data-testid={testId}
          autoComplete={autoComplete}
          className={`w-full bg-background border text-foreground font-mono py-2.5 focus:outline-none focus:border-primary transition-colors text-sm ${
            icon ? "pl-9 pr-3" : "px-3"
          } ${error ? "border-destructive/60" : "border-border"}`}
        />
      </div>
      {error && <p className="text-[9px] text-destructive font-mono">{error}</p>}
    </div>
  );
}

function PasswordField({
  label, value, onChange, show, onToggle, error, testId, autoComplete,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  show: boolean;
  onToggle: () => void;
  error?: string;
  testId?: string;
  autoComplete?: string;
}) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[9px] text-muted-foreground font-mono uppercase tracking-widest">{label}</label>
      <div className="relative">
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none">
          <Lock size={12} />
        </span>
        <input
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          data-testid={testId}
          autoComplete={autoComplete}
          placeholder="••••••••"
          className={`w-full bg-background border text-foreground font-mono pl-9 pr-10 py-2.5 focus:outline-none focus:border-primary transition-colors text-sm ${
            error ? "border-destructive/60" : "border-border"
          }`}
        />
        <button
          type="button"
          onClick={onToggle}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
          tabIndex={-1}
        >
          {show ? <EyeOff size={13} /> : <Eye size={13} />}
        </button>
      </div>
      {error && <p className="text-[9px] text-destructive font-mono">{error}</p>}
    </div>
  );
}
