import {
  useGetMe,
  useRequestWithdrawal,
  useGetWithdrawalFeePreview,
  getGetMeQueryKey,
  getListWithdrawalsQueryKey,
  getGetWithdrawalFeePreviewQueryKey,
} from "@workspace/api-client-react";
import { useState } from "react";
import { Wallet, AlertTriangle, ArrowRight, Clock, Info, ShieldAlert, Lock } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

const MIN_WITHDRAWAL = 10;

export default function Withdraw() {
  const { data: user, isLoading } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: feePreview } = useGetWithdrawalFeePreview({
    query: { queryKey: getGetWithdrawalFeePreviewQueryKey() },
  });
  const requestWithdrawal = useRequestWithdrawal();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [amount, setAmount] = useState<string>("");
  const [walletAddress, setWalletAddress] = useState<string>("");
  const [network, setNetwork] = useState<"TON" | "TRX" | "ETH" | "BSC">("TON");

  if (isLoading || !user) {
    return <div className="p-4 text-center text-primary font-mono text-sm animate-pulse">ACCESSING LEDGER...</div>;
  }

  const amountNum = parseFloat(amount) || 0;
  const feePercent = feePreview?.feePercent ?? 1;
  const feeAmount = amountNum * feePercent / 100;
  const netAmount = amountNum - feeAmount;
  const available = parseFloat(user.availableBalance);

  // 48h wallet lockout
  const walletLockoutUntil = feePreview?.walletLockoutUntil ?? null;
  const isWalletLocked = !!walletLockoutUntil && new Date(walletLockoutUntil) > new Date();
  const lockoutRemaining = walletLockoutUntil
    ? formatDistanceToNow(new Date(walletLockoutUntil), { addSuffix: false })
    : null;

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !walletAddress) return;

    requestWithdrawal.mutate({ data: { amount, walletAddress, network } }, {
      onSuccess: () => {
        toast({
          title: "Withdrawal Queued",
          description: `${netAmount.toFixed(2)} GEL net payout initiated (24h pending period).`,
          className: "bg-card border-primary text-primary",
        });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListWithdrawalsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetWithdrawalFeePreviewQueryKey() });
        setAmount("");
        setWalletAddress("");
      },
      onError: (err: any) => {
        toast({ title: "Withdrawal Failed", description: err?.data?.error ?? err.message ?? "Unknown error", variant: "destructive" });
      },
    });
  };

  return (
    <div className="p-4 flex flex-col gap-4 pb-20">
      <header className="mb-1">
        <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
          <Wallet className="text-primary" size={22} />
          Withdraw
        </h1>
        <p className="text-xs text-muted-foreground mt-1">Extract generated earnings to external wallet. Earnings only — principal is non-refundable.</p>
      </header>

      {/* Balance card */}
      <div className="border border-primary bg-primary/5 p-4 relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-[0.05]"><Wallet size={80} className="text-primary -mt-2 -mr-2" /></div>
        <p className="text-[10px] text-muted-foreground font-mono uppercase mb-1">Available Earnings</p>
        <p className="text-3xl font-bold text-primary font-mono tracking-tighter" data-testid="text-available-balance">
          {available.toFixed(2)} <span className="text-lg text-muted-foreground">GEL</span>
        </p>
        <div className="mt-3 pt-3 border-t border-primary/20 flex gap-2 items-start">
          <AlertTriangle size={12} className="text-destructive shrink-0 mt-0.5" />
          <p className="text-[9px] text-muted-foreground uppercase leading-relaxed font-mono">
            Principal is permanently locked — only earnings can be withdrawn. Min: {MIN_WITHDRAWAL} GEL.
          </p>
        </div>
      </div>

      {/* 48h Wallet Security Lockout Banner */}
      {isWalletLocked && (
        <div className="border border-yellow-500/50 bg-yellow-500/10 p-4 flex items-start gap-3" data-testid="banner-wallet-lockout">
          <Lock size={16} className="text-yellow-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-xs font-bold font-mono text-yellow-400 uppercase mb-1">Security Lockout — Withdrawals Frozen</p>
            <p className="text-[10px] text-yellow-400/80 font-mono leading-relaxed">
              You recently updated your wallet address. Withdrawals are blocked for <span className="font-bold text-yellow-400">{lockoutRemaining}</span> more for your security.
            </p>
            <Link href="/profile" className="text-[10px] text-primary font-mono uppercase mt-2 flex items-center gap-1 hover:underline">
              View wallet settings <ArrowRight size={9} />
            </Link>
          </div>
        </div>
      )}

      {/* Dynamic fee info */}
      {feePreview && !isWalletLocked && (
        <div className="border border-border bg-card p-3 flex items-start gap-2.5">
          <Info size={13} className="text-primary shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-[10px] text-muted-foreground font-mono uppercase mb-1">Current Withdrawal Fee</p>
            <div className="flex justify-between items-center">
              <p className="text-sm font-bold font-mono text-foreground">{feePreview.feePercent}% fee</p>
              <span className="text-[10px] text-muted-foreground font-mono border border-border px-1.5 py-0.5">{feePreview.feeLabel}</span>
            </div>
            <p className="text-[9px] text-muted-foreground mt-1 font-mono">
              Withdraw more frequently = higher fee. Wait &gt;7 days = 1% fee.
            </p>
          </div>
        </div>
      )}

      {/* Saved wallet quick-fill */}
      {user.walletAddress && !walletAddress && (
        <div className="border border-border bg-card p-3 flex items-center justify-between gap-3">
          <div className="flex-1 min-w-0">
            <p className="text-[9px] text-muted-foreground font-mono uppercase mb-0.5">Saved Wallet</p>
            <p className="text-xs font-mono text-foreground truncate">{user.walletAddress}</p>
          </div>
          <button
            onClick={() => setWalletAddress(user.walletAddress!)}
            className="text-[9px] text-primary font-mono uppercase px-2.5 py-1.5 border border-primary/30 bg-primary/5 hover:bg-primary/10 shrink-0 transition-colors"
            data-testid="button-use-saved-wallet"
          >
            USE
          </button>
        </div>
      )}

      <form onSubmit={handleWithdraw} className="flex flex-col gap-4">
        {/* Network selector */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-muted-foreground uppercase font-mono">Network</label>
          <div className="grid grid-cols-4 gap-2">
            {(["TON", "TRX", "ETH", "BSC"] as const).map((n) => (
              <button
                type="button"
                key={n}
                onClick={() => setNetwork(n)}
                data-testid={`button-network-${n}`}
                className={`py-2 text-xs font-mono font-bold border transition-colors ${network === n ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border text-foreground hover:border-primary/50"}`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>

        {/* Amount input */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-muted-foreground uppercase font-mono">Amount (GEL)</label>
          <div className="relative">
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              min={MIN_WITHDRAWAL}
              max={available}
              step="0.01"
              required
              disabled={isWalletLocked}
              data-testid="input-withdraw-amount"
              className="w-full bg-background border border-border text-foreground font-mono px-4 py-3 focus:outline-none focus:border-primary transition-colors pr-16 disabled:opacity-50 disabled:cursor-not-allowed"
              placeholder={`Min: ${MIN_WITHDRAWAL} GEL`}
            />
            <button
              type="button"
              onClick={() => setAmount(String(available))}
              disabled={isWalletLocked}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-[9px] text-primary uppercase font-mono px-2 py-1 bg-primary/10 border border-primary/20 hover:bg-primary/20 disabled:opacity-50"
            >
              MAX
            </button>
          </div>
        </div>

        {/* Wallet address */}
        <div className="flex flex-col gap-2">
          <label className="text-[10px] text-muted-foreground uppercase font-mono">Receiving Address</label>
          <input
            type="text"
            value={walletAddress}
            onChange={(e) => setWalletAddress(e.target.value)}
            required
            disabled={isWalletLocked}
            data-testid="input-wallet-address"
            className="w-full bg-background border border-border text-foreground font-mono px-4 py-3 focus:outline-none focus:border-primary transition-colors text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            placeholder={`Enter ${network} address...`}
          />
        </div>

        {/* Fee breakdown preview */}
        {amountNum >= MIN_WITHDRAWAL && !isWalletLocked && (
          <div className="border border-border bg-card p-3 flex flex-col gap-1.5 font-mono text-xs">
            <div className="flex justify-between text-muted-foreground">
              <span>Requested</span>
              <span>{amountNum.toFixed(2)} GEL</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>Fee ({feePercent}%)</span>
              <span className="text-destructive">−{feeAmount.toFixed(2)} GEL</span>
            </div>
            <div className="flex justify-between text-foreground font-bold border-t border-border pt-1.5 mt-0.5">
              <span>You Receive</span>
              <span className="text-primary">{netAmount.toFixed(2)} GEL</span>
            </div>
          </div>
        )}

        {/* 24h pending notice */}
        {!isWalletLocked && (
          <div className="flex items-start gap-2 border border-border/50 bg-card/50 p-2.5">
            <Clock size={11} className="text-muted-foreground shrink-0 mt-0.5" />
            <p className="text-[9px] text-muted-foreground font-mono uppercase leading-relaxed">
              24-hour pending period before payout is processed. Funds are deducted immediately on request.
            </p>
          </div>
        )}

        <button
          type="submit"
          disabled={
            isWalletLocked ||
            requestWithdrawal.isPending ||
            amountNum < MIN_WITHDRAWAL ||
            amountNum > available ||
            !walletAddress
          }
          data-testid="button-confirm-withdrawal"
          className="w-full mt-1 bg-primary text-primary-foreground font-bold uppercase tracking-widest py-4 hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isWalletLocked ? (
            <><Lock size={14} /> WITHDRAWALS LOCKED</>
          ) : requestWithdrawal.isPending ? (
            "PROCESSING..."
          ) : (
            <>CONFIRM EXTRACTION <ArrowRight size={15} /></>
          )}
        </button>
      </form>
    </div>
  );
}
