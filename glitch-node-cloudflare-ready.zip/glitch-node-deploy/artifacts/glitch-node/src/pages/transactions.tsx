import { useListTransactions, getListTransactionsQueryKey } from "@workspace/api-client-react";
import { useState } from "react";
import { format } from "date-fns";
import {
  ArrowUpRight, ArrowDownRight, Zap, RefreshCcw,
  Package, ChevronDown, Filter
} from "lucide-react";
import { Link } from "wouter";

type TxType = "all" | "earning" | "deposit" | "withdrawal" | "compound" | "referral_bonus";

const TYPE_CONFIG: Record<string, {
  icon: React.ReactNode;
  label: string;
  colorClass: string;
  bgClass: string;
  badgeClass: string;
}> = {
  earning: {
    icon: <Zap size={14} />,
    label: "Click Reward",
    colorClass: "text-primary",
    bgClass: "bg-primary/10",
    badgeClass: "border-primary/30 text-primary bg-primary/10",
  },
  deposit: {
    icon: <ArrowDownRight size={14} />,
    label: "Deposit",
    colorClass: "text-emerald-400",
    bgClass: "bg-emerald-500/10",
    badgeClass: "border-emerald-500/30 text-emerald-400 bg-emerald-500/10",
  },
  withdrawal: {
    icon: <ArrowUpRight size={14} />,
    label: "Withdrawal",
    colorClass: "text-orange-400",
    bgClass: "bg-orange-500/10",
    badgeClass: "border-orange-500/30 text-orange-400 bg-orange-500/10",
  },
  compound: {
    icon: <Package size={14} />,
    label: "Compound",
    colorClass: "text-yellow-400",
    bgClass: "bg-yellow-500/10",
    badgeClass: "border-yellow-500/30 text-yellow-400 bg-yellow-500/10",
  },
  referral_bonus: {
    icon: <RefreshCcw size={14} />,
    label: "Referral Bonus",
    colorClass: "text-primary",
    bgClass: "bg-primary/10",
    badgeClass: "border-primary/30 text-primary bg-primary/10",
  },
};

const STATUS_BADGE: Record<string, string> = {
  pending: "border-yellow-500/40 text-yellow-400 bg-yellow-500/10",
  completed: "border-emerald-500/40 text-emerald-400 bg-emerald-500/10",
  failed: "border-destructive/40 text-destructive bg-destructive/10",
};

const FILTER_TABS: { value: TxType; label: string }[] = [
  { value: "all", label: "ALL" },
  { value: "earning", label: "REWARDS" },
  { value: "deposit", label: "DEPOSITS" },
  { value: "withdrawal", label: "WITHDRAWALS" },
  { value: "compound", label: "COMPOUND" },
  { value: "referral_bonus", label: "REFERRAL" },
];

export default function Transactions() {
  const [activeFilter, setActiveFilter] = useState<TxType>("all");
  const [showFilters, setShowFilters] = useState(false);

  const { data: transactions, isLoading } = useListTransactions(
    activeFilter !== "all" ? { type: activeFilter } : {},
    { query: { queryKey: getListTransactionsQueryKey(activeFilter !== "all" ? { type: activeFilter } : {}) } }
  );

  if (isLoading) {
    return (
      <div className="p-4 flex flex-col gap-3 animate-pulse">
        <div className="h-8 w-48 bg-card border border-border" />
        <div className="h-10 bg-card border border-border" />
        {[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-card border border-border" />)}
      </div>
    );
  }

  return (
    <div className="p-4 flex flex-col gap-4 pb-20">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
            <Zap className="text-primary" size={20} />
            Ledger History
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Complete transaction log — all amounts in GEL</p>
        </div>
        <button
          onClick={() => setShowFilters((v) => !v)}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 border text-[10px] font-mono uppercase tracking-widest transition-colors ${showFilters ? "border-primary text-primary bg-primary/10" : "border-border text-muted-foreground hover:border-primary/50"}`}
        >
          <Filter size={10} />
          Filter
          <ChevronDown size={10} className={`transition-transform ${showFilters ? "rotate-180" : ""}`} />
        </button>
      </header>

      {/* Filter tabs */}
      {showFilters && (
        <div className="flex flex-wrap gap-1.5">
          {FILTER_TABS.map((tab) => (
            <button
              key={tab.value}
              onClick={() => setActiveFilter(tab.value)}
              data-testid={`filter-${tab.value}`}
              className={`px-2.5 py-1 text-[9px] font-mono uppercase tracking-widest border transition-colors ${
                activeFilter === tab.value
                  ? "border-primary text-primary bg-primary/10"
                  : "border-border text-muted-foreground hover:border-primary/30"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap gap-2">
        {Object.entries(TYPE_CONFIG).slice(0, 4).map(([type, cfg]) => (
          <div key={type} className={`flex items-center gap-1 px-1.5 py-0.5 border text-[9px] font-mono ${cfg.badgeClass}`}>
            {cfg.icon} {cfg.label}
          </div>
        ))}
      </div>

      {/* Transaction list */}
      <div className="border border-border bg-card overflow-hidden">
        {!transactions || transactions.length === 0 ? (
          <div className="p-10 text-center font-mono text-xs text-muted-foreground uppercase flex flex-col items-center gap-2">
            <Zap size={24} className="opacity-20" />
            No transactions yet
          </div>
        ) : (
          <div className="flex flex-col divide-y divide-border">
            {transactions.map((tx) => {
              const cfg = TYPE_CONFIG[tx.type] ?? TYPE_CONFIG.deposit;
              const isPositive = parseFloat(tx.amount) > 0;
              const hasFee = parseFloat(tx.feeAmount ?? "0") > 0;

              return (
                <div key={tx.id} className="p-3 hover:bg-muted/5 transition-colors" data-testid={`row-tx-${tx.id}`}>
                  <div className="flex items-start gap-3">
                    {/* Type icon */}
                    <div className={`p-2 mt-0.5 shrink-0 ${cfg.bgClass} ${cfg.colorClass}`}>
                      {cfg.icon}
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
                        <span className={`text-[9px] px-1.5 py-0.5 border font-mono uppercase font-bold ${cfg.badgeClass}`}>
                          {cfg.label}
                        </span>
                        <span className={`text-[9px] px-1.5 py-0.5 border font-mono uppercase ${STATUS_BADGE[tx.status ?? "completed"]}`}>
                          {tx.status ?? "completed"}
                        </span>
                      </div>
                      <p className="text-[10px] text-muted-foreground font-mono">{format(new Date(tx.createdAt), "MMM d, yyyy · HH:mm")}</p>
                      {hasFee && (
                        <p className="text-[9px] text-muted-foreground mt-0.5 font-mono">
                          Fee: {parseFloat(tx.feeAmount ?? "0").toFixed(2)} GEL · Net: {parseFloat(tx.netAmount ?? tx.amount).toFixed(2)} GEL
                        </p>
                      )}
                    </div>

                    {/* Amount */}
                    <div className="text-right shrink-0">
                      <p className={`text-sm font-mono font-bold ${isPositive ? cfg.colorClass : "text-foreground"}`}>
                        {isPositive ? "+" : ""}{parseFloat(tx.amount).toFixed(2)}
                        <span className="text-[9px] text-muted-foreground ml-0.5">GEL</span>
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
