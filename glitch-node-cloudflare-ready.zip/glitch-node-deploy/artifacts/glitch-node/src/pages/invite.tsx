import { useListReferrals, getListReferralsQueryKey, getGetMeQueryKey, getGetDashboardQueryKey } from "@workspace/api-client-react";
import { Users, Copy, Check, Zap, ShieldAlert, Activity } from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

export default function Invite() {
  const { data: stats, isLoading } = useListReferrals({ query: { queryKey: getListReferralsQueryKey() } });
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  if (isLoading || !stats) {
    return (
      <div className="p-4 flex flex-col gap-3 animate-pulse">
        <div className="h-8 w-40 bg-card border border-border" />
        <div className="h-20 bg-card border border-border" />
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3].map((i) => <div key={i} className="h-20 bg-card border border-border" />)}
        </div>
      </div>
    );
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(stats.referralLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
      toast({ description: "Referral link copied to clipboard.", className: "bg-card border-primary text-primary" });
    });
  };

  return (
    <div className="p-4 flex flex-col gap-4 pb-20">
      <header className="mb-1">
        <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
          <Users className="text-primary" size={22} />
          Network
        </h1>
        <p className="text-xs text-muted-foreground mt-1">Earn 5% referral bonus on every friend's click yield — but only when you're also actively clicking.</p>
      </header>

      {/* Referral Link */}
      <div className="border border-primary/50 bg-primary/5 p-4">
        <p className="text-[10px] text-muted-foreground font-mono uppercase tracking-widest mb-2">Your Invite Link</p>
        <div className="flex gap-2">
          <div className="flex-1 bg-background border border-border px-3 py-2 text-xs font-mono truncate text-foreground flex items-center">
            {stats.referralLink}
          </div>
          <button
            onClick={handleCopy}
            data-testid="button-copy-referral"
            className="bg-primary text-primary-foreground px-4 flex items-center justify-center gap-2 transition-colors hover:bg-primary/80 shrink-0"
          >
            {copied ? <><Check size={16} /> <span className="text-xs font-mono hidden sm:block">COPIED</span></> : <><Copy size={16} /></>}
          </button>
        </div>
        <p className="text-[9px] text-muted-foreground font-mono mt-2 uppercase">
          Referral code: <span className="text-primary">{stats.referralCode}</span>
        </p>
      </div>

      {/* Stats Grid — 3 cards */}
      <div className="grid grid-cols-3 gap-2">
        <div className="border border-border bg-card p-3 text-center" data-testid="stat-total-invited">
          <p className="text-2xl font-mono font-bold text-foreground">{stats.totalReferrals}</p>
          <p className="text-[9px] text-muted-foreground font-mono uppercase mt-1 leading-tight">Total Invited</p>
        </div>
        <div className="border border-primary/30 bg-primary/5 p-3 text-center" data-testid="stat-active-friends">
          <div className="flex items-center justify-center gap-1 mb-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
            <p className="text-2xl font-mono font-bold text-primary">{stats.currentlyClicking}</p>
          </div>
          <p className="text-[9px] text-primary/70 font-mono uppercase leading-tight">Currently Clicking</p>
        </div>
        <div className="border border-border bg-card p-3 text-center" data-testid="stat-total-earnings">
          <p className="text-2xl font-mono font-bold text-foreground">{parseFloat(stats.totalBonusEarned).toFixed(1)}</p>
          <p className="text-[9px] text-muted-foreground font-mono uppercase mt-1 leading-tight">Bonus GEL</p>
        </div>
      </div>

      {/* Active Packages count */}
      {stats.activeReferrals > 0 && (
        <div className="border border-border bg-card p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity size={13} className="text-primary" />
            <p className="text-xs font-mono text-muted-foreground uppercase">Friends with active packages</p>
          </div>
          <p className="text-sm font-mono font-bold text-foreground">{stats.activeReferrals}</p>
        </div>
      )}

      {/* Anti-fraud note */}
      <div className="border border-border/50 bg-card/50 p-3 flex gap-2 items-start">
        <ShieldAlert size={12} className="text-muted-foreground shrink-0 mt-0.5" />
        <p className="text-[9px] text-muted-foreground font-mono uppercase leading-relaxed">
          Anti-fraud rule: You only earn referral bonuses when your own 6-hour click timer is actively running. Inactive referrers receive no commission.
        </p>
      </div>

      {/* Referral list */}
      <div>
        <h2 className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest mb-2">Recruit Roster</h2>

        {stats.referrals.length === 0 ? (
          <div className="border border-dashed border-border p-8 text-center bg-card/30">
            <Users size={28} className="text-muted-foreground mx-auto mb-2 opacity-40" />
            <p className="text-xs text-muted-foreground font-mono uppercase">No recruits yet</p>
            <p className="text-[10px] text-muted-foreground mt-1">Share your invite link to start earning</p>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {stats.referrals.map((ref) => (
              <div
                key={ref.id}
                className={`border bg-card p-3 flex justify-between items-center ${ref.isCurrentlyClicking ? "border-primary/30" : "border-border"}`}
                data-testid={`row-referral-${ref.id}`}
              >
                <div className="flex items-center gap-2.5">
                  {/* Status indicator */}
                  <div className="relative">
                    <div className={`w-2 h-2 rounded-full ${ref.isCurrentlyClicking ? "bg-primary" : ref.hasDeployed ? "bg-emerald-500" : "bg-muted-foreground/30"}`} />
                    {ref.isCurrentlyClicking && (
                      <div className="absolute inset-0 rounded-full bg-primary animate-ping opacity-75" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-mono text-foreground font-bold">
                      {ref.username ? `@${ref.username}` : (ref.firstName || "Anonymous")}
                    </p>
                    <p className="text-[9px] text-muted-foreground font-mono uppercase mt-0.5">
                      Joined {format(new Date(ref.joinedAt), "MMM d, yyyy")}
                    </p>
                  </div>
                </div>

                <div className="text-right flex flex-col items-end gap-1">
                  {ref.isCurrentlyClicking ? (
                    <span className="text-[9px] px-1.5 py-0.5 border border-primary/30 text-primary font-mono bg-primary/10 flex items-center gap-1">
                      <Zap size={8} /> CLICKING
                    </span>
                  ) : ref.hasDeployed ? (
                    <span className="text-[9px] px-1.5 py-0.5 border border-emerald-500/30 text-emerald-400 font-mono bg-emerald-500/10">ACTIVE</span>
                  ) : (
                    <span className="text-[9px] px-1.5 py-0.5 border border-border text-muted-foreground font-mono">INACTIVE</span>
                  )}
                  <p className="text-[10px] text-primary font-mono">+{parseFloat(ref.bonusEarned).toFixed(2)} GEL</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
