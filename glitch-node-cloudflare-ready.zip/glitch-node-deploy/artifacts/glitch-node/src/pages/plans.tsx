import {
  useCreateInvoice,
  getGetDashboardQueryKey,
  getListPackagesQueryKey,
  getGetInvestStatusQueryKey,
  useGetInvestStatus,
  getGetMeQueryKey,
} from "@workspace/api-client-react";
import { useState, useEffect, useRef } from "react";
import { ShieldAlert, Zap, Package, Clock, ExternalLink, RefreshCcw, CheckCircle, XCircle, Loader2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

const PACKAGE_TIERS = [
  { amount: 25, label: "Micro", dailyMax: "0.25", popular: false },
  { amount: 50, label: "Starter", dailyMax: "0.50", popular: false },
  { amount: 100, label: "Basic", dailyMax: "1.00", popular: true },
  { amount: 150, label: "Standard", dailyMax: "1.50", popular: false },
  { amount: 400, label: "Pro", dailyMax: "4.00", popular: false },
  { amount: 1000, label: "Advanced", dailyMax: "10.00", popular: false },
  { amount: 2500, label: "Elite", dailyMax: "25.00", popular: false },
  { amount: 5000, label: "Ultra", dailyMax: "50.00", popular: false },
] as const;

type PaymentState =
  | { stage: "idle" }
  | { stage: "creating" }
  | { stage: "waiting"; invoiceId: string; payUrl: string; amountGel: number; amountUsdt: string }
  | { stage: "confirmed"; amountGel: number }
  | { stage: "error"; message: string };

export default function Plans() {
  const createInvoice = useCreateInvoice();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const [selected, setSelected] = useState<number | null>(null);
  const [payment, setPayment] = useState<PaymentState>({ stage: "idle" });

  // Track package count before payment to detect confirmation
  const prevPackageCount = useRef<number | null>(null);

  const { data: investStatus } = useGetInvestStatus({
    query: {
      queryKey: getGetInvestStatusQueryKey(),
      refetchInterval: payment.stage === "waiting" ? 4000 : false,
    },
  });

  // Detect package activation via polling during "waiting" state
  useEffect(() => {
    if (payment.stage !== "waiting") return;

    if (prevPackageCount.current === null && investStatus) {
      prevPackageCount.current = investStatus.totalPackages;
      return;
    }

    if (
      investStatus &&
      prevPackageCount.current !== null &&
      investStatus.totalPackages > prevPackageCount.current
    ) {
      // Payment confirmed — package was activated
      const gel = (payment as Extract<PaymentState, { stage: "waiting" }>).amountGel;
      setPayment({ stage: "confirmed", amountGel: gel });
      queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
      queryClient.invalidateQueries({ queryKey: getListPackagesQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetInvestStatusQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      prevPackageCount.current = null;
    }
  }, [investStatus, payment]);

  const handlePurchase = () => {
    if (!selected) return;

    setPayment({ stage: "creating" });

    createInvoice.mutate({ data: { amountGel: selected as any } }, {
      onSuccess: (invoice) => {
        // Record current package count so we can detect change
        prevPackageCount.current = investStatus?.totalPackages ?? null;
        setPayment({
          stage: "waiting",
          invoiceId: invoice.invoiceId,
          payUrl: invoice.payUrl,
          amountGel: invoice.amountGel,
          amountUsdt: invoice.amountUsdt,
        });
        // Open Telegram Crypto Bot payment page
        openPaymentLink(invoice.payUrl);
      },
      onError: (err: any) => {
        const message = err?.data?.error ?? err?.message ?? "Unknown error";
        setPayment({ stage: "error", message });
        toast({ title: "Invoice Failed", description: message, variant: "destructive" });
      },
    });
  };

  const handleCancel = () => {
    setPayment({ stage: "idle" });
    prevPackageCount.current = null;
  };

  const handleDone = () => {
    setPayment({ stage: "idle" });
    setSelected(null);
    setLocation("/bots");
  };

  // ── Payment overlay ────────────────────────────────────────────────────────

  if (payment.stage === "confirmed") {
    return (
      <div className="p-6 flex flex-col items-center justify-center min-h-[70vh] gap-6 text-center">
        <div className="w-16 h-16 flex items-center justify-center bg-primary/10 border border-primary">
          <CheckCircle size={36} className="text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-bold font-mono uppercase tracking-widest text-foreground">Payment Confirmed</h2>
          <p className="text-muted-foreground text-sm mt-2 font-mono">
            {payment.amountGel} GEL package activated. 180-day lifespan started.
          </p>
        </div>
        <div className="flex items-center gap-1.5 border border-primary/30 px-4 py-2 bg-primary/5">
          <Zap size={12} className="text-primary" />
          <p className="text-xs font-mono text-primary uppercase">Yield clicks now active</p>
        </div>
        <button
          onClick={handleDone}
          className="w-full py-3.5 bg-primary text-primary-foreground font-bold font-mono uppercase tracking-widest text-sm hover:bg-primary/80 transition-colors"
        >
          VIEW PACKAGES →
        </button>
      </div>
    );
  }

  if (payment.stage === "waiting") {
    const p = payment as Extract<PaymentState, { stage: "waiting" }>;
    return (
      <div className="p-4 flex flex-col items-center min-h-[70vh] gap-6 pb-20">
        <div className="w-full max-w-sm mx-auto flex flex-col items-center gap-5 mt-8">
          {/* Animated ring */}
          <div className="relative w-20 h-20 flex items-center justify-center">
            <div className="absolute inset-0 border-2 border-primary/20 rounded-none" />
            <div className="absolute inset-0 border-t-2 border-primary animate-spin" style={{ animationDuration: "1.5s" }} />
            <Loader2 size={28} className="text-primary animate-spin" />
          </div>

          <div className="text-center">
            <h2 className="text-lg font-bold font-mono uppercase tracking-widest text-foreground">Waiting for Payment</h2>
            <p className="text-xs text-muted-foreground font-mono mt-1">
              Monitoring Crypto Pay for your <span className="text-primary font-bold">{p.amountGel} GEL</span> deposit
            </p>
          </div>

          {/* Invoice details */}
          <div className="w-full border border-border bg-card p-4 flex flex-col gap-2 font-mono text-xs">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Invoice ID</span>
              <span className="text-foreground">#{p.invoiceId}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">You Pay</span>
              <span className="text-foreground">{p.amountUsdt} USDT</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Package</span>
              <span className="text-primary">{p.amountGel} GEL</span>
            </div>
          </div>

          <p className="text-[10px] text-muted-foreground font-mono uppercase text-center leading-relaxed px-2">
            The package activates automatically once Crypto Pay confirms the transfer. This page updates live.
          </p>

          {/* Re-open payment button */}
          <button
            onClick={() => openPaymentLink(p.payUrl)}
            className="w-full py-3 border border-primary text-primary font-bold font-mono uppercase tracking-widest text-sm flex items-center justify-center gap-2 hover:bg-primary/10 transition-colors"
          >
            <ExternalLink size={14} /> OPEN CRYPTO PAY AGAIN
          </button>

          {/* Manual refresh */}
          <button
            onClick={() => {
              queryClient.invalidateQueries({ queryKey: getGetInvestStatusQueryKey() });
              queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
            }}
            className="text-[10px] text-muted-foreground font-mono uppercase flex items-center gap-1 hover:text-foreground transition-colors"
          >
            <RefreshCcw size={9} /> Check manually
          </button>

          <button
            onClick={handleCancel}
            className="text-[10px] text-muted-foreground font-mono uppercase hover:text-destructive transition-colors flex items-center gap-1"
          >
            <XCircle size={9} /> Cancel / go back
          </button>
        </div>
      </div>
    );
  }

  // ── Main plan selection ────────────────────────────────────────────────────

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header>
        <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
          <Package className="text-primary" size={22} />
          Purchase Package
        </h1>
        <p className="text-xs text-muted-foreground mt-1">
          Fixed-price investment tiers. Pay via <span className="text-primary font-bold">@CryptoBot</span> (USDT). 180-day lifespan. Max 4% daily via manual clicks.
        </p>
      </header>

      {/* Rules card */}
      <div className="border border-border bg-card p-3 flex flex-col gap-2">
        {[
          { icon: <Clock size={10} />, text: "180-day lock period per package" },
          { icon: <Zap size={10} />, text: "Max 4 clicks/day — 1% of principal each" },
          { icon: <ShieldAlert size={10} />, text: "Principal is permanent — only earnings are withdrawable" },
        ].map((r, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className="text-primary">{r.icon}</span>
            <p className="text-[10px] text-muted-foreground font-mono uppercase">{r.text}</p>
          </div>
        ))}
      </div>

      {/* Package grid */}
      <div className="grid grid-cols-2 gap-2">
        {PACKAGE_TIERS.map((tier) => (
          <div
            key={tier.amount}
            onClick={() => setSelected(tier.amount)}
            data-testid={`card-tier-${tier.amount}`}
            className={`border p-3 cursor-pointer transition-all relative overflow-hidden
              ${selected === tier.amount
                ? "border-primary bg-primary/10 shadow-[0_0_12px_rgba(0,255,255,0.12)]"
                : "border-border bg-card hover:border-primary/40"}`}
          >
            {tier.popular && (
              <div className="absolute top-0 right-0 bg-primary px-1.5 py-0.5">
                <p className="text-[8px] text-primary-foreground font-mono font-bold uppercase">POPULAR</p>
              </div>
            )}
            {selected === tier.amount && (
              <div className="absolute bottom-1 right-1 text-primary opacity-60"><Zap size={16} /></div>
            )}
            <p className="text-[10px] text-muted-foreground uppercase font-mono mb-0.5">{tier.label}</p>
            <p className="text-2xl font-bold font-mono text-foreground">{tier.amount}</p>
            <p className="text-[10px] text-muted-foreground font-mono">GEL</p>
            <div className="mt-2 pt-2 border-t border-border">
              <p className="text-[9px] text-muted-foreground uppercase">Max daily</p>
              <p className="text-xs font-mono text-primary">+{tier.dailyMax} GEL</p>
            </div>
          </div>
        ))}
      </div>

      {/* Confirm panel */}
      {selected && (
        <div className="fixed bottom-[70px] left-1/2 -translate-x-1/2 w-full max-w-[375px] px-4 pb-3 pt-3 bg-card border-t border-primary z-30">
          <div className="mb-2 p-2.5 bg-destructive/10 border border-destructive/20 flex items-start gap-2">
            <ShieldAlert size={13} className="text-destructive shrink-0 mt-0.5" />
            <p className="text-[10px] text-destructive uppercase font-mono leading-relaxed">
              {selected} GEL will be permanently locked as principal. Only earnings can be withdrawn.
            </p>
          </div>

          {/* Payment method badge */}
          <div className="mb-2.5 flex items-center gap-1.5 text-[9px] text-muted-foreground font-mono uppercase">
            <div className="w-1.5 h-1.5 bg-primary rounded-full" />
            Powered by Crypto Pay (@CryptoBot) · USDT payment
          </div>

          <button
            onClick={handlePurchase}
            disabled={payment.stage === "creating"}
            data-testid="button-purchase-package"
            className="w-full py-3.5 bg-primary text-primary-foreground font-bold font-mono uppercase tracking-widest text-sm disabled:opacity-50 flex items-center justify-center gap-2 hover:bg-primary/80 transition-colors"
          >
            {payment.stage === "creating"
              ? <><Loader2 size={14} className="animate-spin" /> CREATING INVOICE...</>
              : <><ExternalLink size={14} /> PAY {selected} GEL VIA CRYPTOBOT</>
            }
          </button>
        </div>
      )}
    </div>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function openPaymentLink(payUrl: string) {
  try {
    const tg = (window as any).Telegram?.WebApp;
    if (tg?.openLink) {
      tg.openLink(payUrl);
    } else if (tg?.openTelegramLink) {
      tg.openTelegramLink(payUrl);
    } else {
      window.open(payUrl, "_blank", "noopener,noreferrer");
    }
  } catch {
    window.open(payUrl, "_blank", "noopener,noreferrer");
  }
}
