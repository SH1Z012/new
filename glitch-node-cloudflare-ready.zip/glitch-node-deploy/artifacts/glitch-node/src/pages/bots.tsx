import { useListPackages, useCompoundEarnings, getListPackagesQueryKey, getGetDashboardQueryKey, getGetInvestStatusQueryKey, getGetMeQueryKey, useGetMe } from "@workspace/api-client-react";
import { useState } from "react";
import { Package, Zap, Clock, ShieldAlert, ArrowRight } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const COMPOUND_AMOUNTS = [25, 50, 100, 150, 400, 1000, 2500, 5000] as const;

export default function Bots() {
  const { data: packages, isLoading } = useListPackages({ query: { queryKey: getListPackagesQueryKey() } });
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const compoundEarnings = useCompoundEarnings();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [showCompound, setShowCompound] = useState(false);
  const [compoundAmount, setCompoundAmount] = useState<number | null>(null);

  const handleCompound = () => {
    if (!compoundAmount) return;
    compoundEarnings.mutate({ data: { amount: compoundAmount as any } }, {
      onSuccess: () => {
        toast({
          title: "Compound Successful",
          description: `${compoundAmount} GEL reinvested as new sub-package. 0% fee.`,
          className: "bg-card border-primary text-primary",
        });
        queryClient.invalidateQueries({ queryKey: getListPackagesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetInvestStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        setShowCompound(false);
        setCompoundAmount(null);
      },
      onError: (err: any) => {
        toast({ title: "Compound Failed", description: err?.data?.error ?? err.message ?? "Unknown error", variant: "destructive" });
      },
    });
  };

  if (isLoading || !packages) {
    return <div className="p-4 text-center text-primary font-mono text-sm animate-pulse">SCANNING PACKAGES...</div>;
  }

  const activePackages = packages.filter((p) => p.isActive);
  const expiredPackages = packages.filter((p) => !p.isActive);
  const availableBalance = parseFloat(user?.availableBalance ?? "0");
  const activePrincipal = activePackages.reduce((sum, p) => sum + parseFloat(p.amount), 0);

  return (
    <div className="p-4 flex flex-col gap-4 pb-24">
      <header className="flex justify-between items-center">
        <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
          <Package className="text-primary" size={22} />
          My Packages
        </h1>
        <Link href="/plans" className="text-[10px] text-primary uppercase font-mono flex items-center gap-1 border border-primary/30 px-2 py-1">
          + New <ArrowRight size={9} />
        </Link>
      </header>

      <div className="grid grid-cols-2 gap-2">
        <div className="border border-border bg-card p-3">
          <p className="text-[10px] text-muted-foreground uppercase font-mono mb-1">Active Principal</p>
          <p className="text-lg font-mono font-bold text-primary">{activePrincipal.toFixed(2)} GEL</p>
        </div>
        <div className="border border-border bg-card p-3">
          <p className="text-[10px] text-muted-foreground uppercase font-mono mb-1">Earnings</p>
          <p className="text-lg font-mono font-bold text-foreground">{availableBalance.toFixed(2)} GEL</p>
        </div>
      </div>

      {availableBalance >= 25 && (
        <button
          onClick={() => setShowCompound((v) => !v)}
          className="w-full border border-primary/40 bg-primary/5 py-3 font-mono font-bold uppercase text-sm text-primary tracking-widest flex items-center justify-center gap-2 hover:bg-primary/10 transition-colors"
          data-testid="button-compound-toggle"
        >
          <Zap size={14} /> Reinvest (Compound) — 0% Fee
        </button>
      )}

      {showCompound && (
        <div className="border border-primary bg-card p-4 flex flex-col gap-3">
          <p className="text-xs text-muted-foreground font-mono uppercase">Select amount to reinvest from earnings</p>
          <div className="grid grid-cols-4 gap-2">
            {COMPOUND_AMOUNTS.filter((a) => a <= availableBalance).map((a) => (
              <button
                key={a}
                onClick={() => setCompoundAmount(a)}
                data-testid={`button-compound-${a}`}
                className={`py-2 text-xs font-mono font-bold border transition-colors
                  ${compoundAmount === a ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-foreground hover:border-primary/50"}`}
              >
                {a}
              </button>
            ))}
          </div>
          {compoundAmount && (
            <div className="bg-primary/5 border border-primary/20 p-2">
              <p className="text-[10px] text-primary font-mono">
                {compoundAmount} GEL from earnings → new COMPOUND package (0% fee, 180-day)
              </p>
            </div>
          )}
          <button
            onClick={handleCompound}
            disabled={!compoundAmount || compoundEarnings.isPending}
            className="w-full py-3 bg-primary text-primary-foreground font-bold font-mono uppercase tracking-widest text-sm disabled:opacity-40"
            data-testid="button-compound-confirm"
          >
            {compoundEarnings.isPending ? "COMPOUNDING..." : "CONFIRM REINVESTMENT"}
          </button>
        </div>
      )}

      {activePackages.length === 0 ? (
        <div className="border border-dashed border-border bg-card/50 p-8 text-center">
          <Package size={32} className="text-muted-foreground mx-auto mb-3" />
          <p className="text-sm text-muted-foreground font-mono mb-3">No active packages</p>
          <Link href="/plans" className="px-4 py-2 bg-primary/10 text-primary border border-primary/20 text-xs font-mono uppercase hover:bg-primary/20 transition-colors">
            Purchase Package
          </Link>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          <h2 className="text-[10px] text-muted-foreground uppercase font-mono tracking-widest">Active ({activePackages.length})</h2>
          {activePackages.map((pkg) => (
            <div key={pkg.id} className="border border-border bg-card p-4" data-testid={`card-package-${pkg.id}`}>
              <div className="flex justify-between items-start mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className={`text-[9px] px-1.5 py-0.5 font-mono font-bold border ${pkg.type === "PRIMARY" ? "border-primary/30 text-primary bg-primary/5" : "border-yellow-500/30 text-yellow-400 bg-yellow-500/5"}`}>
                      {pkg.type}
                    </span>
                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  </div>
                  <p className="text-xl font-bold font-mono text-foreground">{parseFloat(pkg.amount).toFixed(2)} GEL</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-muted-foreground uppercase font-mono">{pkg.daysRemaining}d left</p>
                  <p className="text-[9px] text-muted-foreground">of 180 days</p>
                </div>
              </div>

              <div className="w-full h-1 bg-border mb-3">
                <div
                  className="h-1 bg-primary transition-all"
                  style={{ width: `${Math.min(100, ((180 - (pkg.daysRemaining ?? 0)) / 180) * 100)}%` }}
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px] text-muted-foreground font-mono">
                <div className="flex items-center gap-1">
                  <Clock size={9} />
                  <span>Expires {format(new Date(pkg.expiresAt), "MMM d, yyyy")}</span>
                </div>
                <div className="flex items-center gap-1 justify-end">
                  <ShieldAlert size={9} className="text-destructive" />
                  <span className="text-destructive">PRINCIPAL LOCKED</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {expiredPackages.length > 0 && (
        <div className="flex flex-col gap-2">
          <h2 className="text-[10px] text-muted-foreground uppercase font-mono tracking-widest">Expired ({expiredPackages.length})</h2>
          {expiredPackages.slice(0, 3).map((pkg) => (
            <div key={pkg.id} className="border border-border/40 bg-card/50 p-3 opacity-50" data-testid={`card-package-expired-${pkg.id}`}>
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-[9px] px-1 py-0.5 font-mono border border-border text-muted-foreground">{pkg.type}</span>
                  <p className="text-base font-mono text-muted-foreground mt-1">{parseFloat(pkg.amount).toFixed(2)} GEL</p>
                </div>
                <p className="text-[10px] text-muted-foreground font-mono">Expired {formatDistanceToNow(new Date(pkg.expiresAt), { addSuffix: true })}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
