import {
  useGetMe,
  useUpdateWallet,
  getGetMeQueryKey,
  getGetWithdrawalFeePreviewQueryKey,
} from "@workspace/api-client-react";
import { useState } from "react";
import { Settings, Wallet, AlertTriangle, Check, Clock, ShieldAlert, User } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow, addHours } from "date-fns";

const NETWORKS = ["TON", "TRX", "ETH", "BSC"] as const;
type Network = (typeof NETWORKS)[number];

export default function Profile() {
  const { data: user, isLoading } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const updateWallet = useUpdateWallet();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [walletAddress, setWalletAddress] = useState("");
  const [network, setNetwork] = useState<Network>("TRX");
  const [showConfirm, setShowConfirm] = useState(false);

  if (isLoading || !user) {
    return (
      <div className="p-4 flex flex-col gap-4 animate-pulse">
        <div className="h-8 w-40 bg-card border border-border" />
        <div className="h-28 bg-card border border-border" />
        <div className="h-52 bg-card border border-border" />
      </div>
    );
  }

  const walletLockoutUntil = user.walletUpdatedAt
    ? addHours(new Date(user.walletUpdatedAt), 48)
    : null;
  const isLocked = walletLockoutUntil && walletLockoutUntil > new Date();
  const lockoutRemaining = isLocked
    ? formatDistanceToNow(walletLockoutUntil, { addSuffix: false })
    : null;

  const handleSave = () => {
    if (!walletAddress.trim() || walletAddress.trim().length < 10) return;
    setShowConfirm(true);
  };

  const confirmSave = () => {
    updateWallet.mutate(
      { data: { walletAddress: walletAddress.trim(), network } },
      {
        onSuccess: (updated) => {
          toast({
            title: "Wallet Updated",
            description: "⚠️ Withdrawals blocked for 48 hours as a security measure.",
            className: "bg-card border-yellow-500 text-yellow-400",
          });
          queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetWithdrawalFeePreviewQueryKey() });
          setWalletAddress("");
          setShowConfirm(false);
        },
        onError: (err: any) => {
          toast({
            title: "Update Failed",
            description: err?.data?.error ?? err.message ?? "Unknown error",
            variant: "destructive",
          });
          setShowConfirm(false);
        },
      }
    );
  };

  const displayName =
    user.firstName
      ? [user.firstName, user.lastName].filter(Boolean).join(" ")
      : user.username
      ? `@${user.username}`
      : `User #${user.id}`;

  return (
    <div className="p-4 flex flex-col gap-4 pb-20">
      <header>
        <h1 className="text-xl font-bold text-foreground font-mono uppercase tracking-widest flex items-center gap-2">
          <Settings className="text-primary" size={22} />
          Profile
        </h1>
      </header>

      {/* User card */}
      <div className="border border-border bg-card p-4 flex items-center gap-4">
        <div className="w-12 h-12 border border-border bg-background flex items-center justify-center shrink-0">
          {user.avatarUrl ? (
            <img src={user.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
          ) : (
            <User size={20} className="text-muted-foreground" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold font-mono text-foreground truncate">{displayName}</p>
          {user.username && <p className="text-xs text-muted-foreground font-mono">@{user.username}</p>}
          <p className="text-[9px] text-muted-foreground font-mono uppercase mt-1">
            ID: {user.telegramId} · Ref: <span className="text-primary">{user.referralCode}</span>
          </p>
        </div>
      </div>

      {/* Balance summary */}
      <div className="grid grid-cols-2 gap-2">
        <div className="border border-border bg-card p-3">
          <p className="text-[9px] text-muted-foreground uppercase font-mono mb-1">Earnings</p>
          <p className="text-base font-mono font-bold text-primary">{parseFloat(user.availableBalance).toFixed(2)} GEL</p>
        </div>
        <div className="border border-border bg-card p-3">
          <p className="text-[9px] text-muted-foreground uppercase font-mono mb-1">Lifetime Earned</p>
          <p className="text-base font-mono font-bold text-foreground">{parseFloat(user.totalEarnings).toFixed(2)} GEL</p>
        </div>
      </div>

      {/* ── Wallet Settings ───────────────────────────────────────────── */}
      <div className="border border-border bg-card">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <Wallet size={16} className="text-primary" />
          <h2 className="text-xs font-bold font-mono uppercase tracking-widest text-foreground">Payout Wallet</h2>
        </div>

        <div className="p-4 flex flex-col gap-4">
          {/* Current wallet */}
          {user.walletAddress && (
            <div className="bg-background border border-border p-3">
              <p className="text-[9px] text-muted-foreground uppercase font-mono mb-1">Current Address</p>
              <p className="text-xs font-mono text-primary break-all">{user.walletAddress}</p>
            </div>
          )}

          {/* 48h lockout banner */}
          {isLocked && (
            <div className="border border-yellow-500/40 bg-yellow-500/10 p-3 flex items-start gap-2">
              <Clock size={13} className="text-yellow-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-bold font-mono text-yellow-400 uppercase">Security Lockout Active</p>
                <p className="text-[10px] text-yellow-400/80 font-mono mt-0.5">
                  Withdrawals are blocked for <span className="font-bold">{lockoutRemaining}</span> more due to a recent wallet change.
                </p>
              </div>
            </div>
          )}

          {/* 48h security warning — always shown */}
          <div className="border border-yellow-500/30 bg-yellow-500/5 p-3 flex items-start gap-2">
            <AlertTriangle size={13} className="text-yellow-500 shrink-0 mt-0.5" />
            <p className="text-[10px] text-yellow-500/90 font-mono uppercase leading-relaxed">
              ⚠️ Note: For your security, updating your wallet address will freeze all withdrawal capabilities for the next 48 hours.
            </p>
          </div>

          {/* Network selector */}
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-muted-foreground uppercase font-mono">Network</label>
            <div className="grid grid-cols-4 gap-2">
              {NETWORKS.map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setNetwork(n)}
                  data-testid={`button-network-${n}`}
                  className={`py-2 text-xs font-mono font-bold border transition-colors ${
                    network === n
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background border-border text-foreground hover:border-primary/50"
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>

          {/* Address input */}
          <div className="flex flex-col gap-2">
            <label className="text-[10px] text-muted-foreground uppercase font-mono">
              New Wallet Address ({network})
            </label>
            <input
              type="text"
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              data-testid="input-wallet-address"
              className="w-full bg-background border border-border text-foreground font-mono px-4 py-3 focus:outline-none focus:border-primary transition-colors text-sm"
              placeholder={`Enter ${network} address...`}
            />
          </div>

          {/* Save / Confirm */}
          {!showConfirm ? (
            <button
              onClick={handleSave}
              disabled={walletAddress.trim().length < 10 || updateWallet.isPending}
              data-testid="button-save-wallet"
              className="w-full py-3 bg-primary text-primary-foreground font-bold font-mono uppercase tracking-widest text-sm disabled:opacity-40 flex items-center justify-center gap-2 hover:bg-primary/80 transition-colors"
            >
              <Wallet size={14} /> Update Wallet Address
            </button>
          ) : (
            <div className="border border-destructive/40 bg-destructive/5 p-4 flex flex-col gap-3">
              <div className="flex items-start gap-2">
                <ShieldAlert size={14} className="text-destructive shrink-0 mt-0.5" />
                <div>
                  <p className="text-xs font-bold font-mono text-destructive uppercase">Confirm Wallet Change</p>
                  <p className="text-[10px] text-destructive/80 font-mono mt-1 leading-relaxed">
                    Saving <span className="text-foreground">{walletAddress.slice(0, 8)}...{walletAddress.slice(-6)}</span> as your {network} payout address will block all withdrawals for 48 hours.
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowConfirm(false)}
                  className="flex-1 py-2.5 border border-border bg-background text-foreground font-mono font-bold uppercase text-xs tracking-widest hover:border-primary/30 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmSave}
                  disabled={updateWallet.isPending}
                  data-testid="button-confirm-wallet"
                  className="flex-1 py-2.5 bg-primary text-primary-foreground font-mono font-bold uppercase text-xs tracking-widest flex items-center justify-center gap-1.5 disabled:opacity-50 hover:bg-primary/80 transition-colors"
                >
                  {updateWallet.isPending ? "SAVING..." : <><Check size={12} /> CONFIRM</>}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
