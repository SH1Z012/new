# Glitch Node — Deployment Guide

## Architecture

```
Cloudflare Pages  ──→  React Frontend (static build)
Railway.app       ──→  Express API Server (Node.js)
Neon.tech         ──→  PostgreSQL Database
```

All three are **free tier** compatible.

---

## Step 1 — Database (Neon.tech) ~5 min

1. Go to https://neon.tech → **Create Account** → **New Project**
2. Name: `glitch-node`, Region: closest to you
3. Copy the **Connection string** (looks like `postgresql://user:pass@host/db?sslmode=require`)
4. Save it — this is your `DATABASE_URL`

---

## Step 2 — API Server (Railway.app) ~10 min

### 2.1 — Upload to GitHub first

```bash
cd glitch-node-deploy/   # this folder
git init
git add .
git commit -m "Initial deploy"
# Create a repo on github.com, then:
git remote add origin https://github.com/YOUR_USER/glitch-node.git
git push -u origin main
```

### 2.2 — Deploy on Railway

1. Go to https://railway.app → **New Project** → **Deploy from GitHub Repo**
2. Select your `glitch-node` repository
3. Railway will auto-detect the `railway.toml` config

### 2.3 — Set Environment Variables on Railway

Go to your service → **Variables** tab, add all of these:

| Variable | Value |
|----------|-------|
| `DATABASE_URL` | Your Neon connection string |
| `PORT` | `8080` |
| `JWT_SECRET` | Random 32+ char string (see below) |
| `APP_URL` | Your Cloudflare Pages URL (set after step 3) |
| `ALLOWED_ORIGINS` | Your Cloudflare Pages URL |
| `TELEGRAM_BOT_TOKEN` | From @BotFather (optional for testing) |
| `CRYPTO_PAY_API_TOKEN` | From @CryptoBot on Telegram |
| `NODE_ENV` | `production` |

**Generate JWT_SECRET:**
```bash
# In any terminal:
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

### 2.4 — Run Database Migration

In Railway → your service → **Shell** tab:
```bash
pnpm run db:push
```

Or from your local machine:
```bash
export DATABASE_URL="postgresql://..."  # your Neon URL
cd glitch-node-deploy
npm install -g pnpm
pnpm install --frozen-lockfile=false
pnpm run db:push
```

After deploy, your API URL will be: `https://YOUR_SERVICE.up.railway.app`

**Test it:** Open `https://YOUR_SERVICE.up.railway.app/api/healthz` — should return `{"status":"ok"}`

---

## Step 3 — Frontend (Cloudflare Pages) ~10 min

### 3.1 — Connect to GitHub

1. Go to https://dash.cloudflare.com → **Pages** → **Create a Project** → **Connect to Git**
2. Select your `glitch-node` repository

### 3.2 — Build Settings

| Setting | Value |
|---------|-------|
| **Framework preset** | None |
| **Build command** | `bash cloudflare-pages-build.sh` |
| **Build output directory** | `artifacts/glitch-node/dist/public` |
| **Root directory** | `/` |
| **Node.js version** | `20` |

### 3.3 — Environment Variables (Cloudflare Pages)

Go to Settings → Environment Variables → **Production**:

| Variable | Value |
|----------|-------|
| `VITE_API_URL` | `https://YOUR_SERVICE.up.railway.app/api` |
| `BASE_PATH` | `/` |
| `PORT` | `3000` |
| `NODE_VERSION` | `20` |

### 3.4 — Deploy

Click **Save and Deploy**. Your site will be live at `https://glitch-node-XXXX.pages.dev`

---

## Step 4 — Connect Frontend ↔ Backend

After you have both URLs:

1. **In Railway** → update `APP_URL` and `ALLOWED_ORIGINS` to your `*.pages.dev` URL
2. **In Cloudflare Pages** → confirm `VITE_API_URL` points to your Railway URL + `/api`
3. Trigger a redeploy on both (or push a small commit)

---

## Step 5 — Custom Domain (optional)

### Cloudflare Pages custom domain:
Pages → your project → **Custom Domains** → Add domain

### Railway custom domain:
Your service → **Settings** → **Domains** → **Generate Domain** or add custom

---

## Testing Checklist

- [ ] `https://YOUR_API.up.railway.app/api/healthz` → `{"status":"ok"}`
- [ ] `https://YOUR_SITE.pages.dev` → Login page loads
- [ ] Register with email → success
- [ ] Dashboard loads with balance
- [ ] Plans page loads packages
- [ ] Invite page shows referral link

---

## Local Development

```bash
# Install dependencies
pnpm install --frozen-lockfile=false

# Create local .env files
cp .env.example .env
cp artifacts/glitch-node/.env.example artifacts/glitch-node/.env.local

# Fill in DATABASE_URL at minimum in .env

# Run database migration
pnpm run db:push

# Start API server (port 8080)
pnpm run dev:api

# In another terminal: start frontend (port 3000)
BASE_PATH=/ PORT=3000 pnpm run dev:frontend
```

---

## Troubleshooting

### "PORT environment variable is required"
→ Set `PORT=3000` in Cloudflare Pages env vars. The old vite.config.ts has been fixed to use a default.

### "Cannot find module @replit/..."
→ These Replit packages have been removed from vite.config.ts and package.json. If you see this error, make sure you're using the fixed files from this repo.

### CORS errors in browser console
→ Make sure `ALLOWED_ORIGINS` on Railway matches your exact Cloudflare Pages URL (no trailing slash).

### Database connection error
→ Neon requires `?sslmode=require` at the end of the DATABASE_URL. Check your connection string.

### Build fails on Cloudflare Pages
→ Check that NODE_VERSION=20 is set. Cloudflare Pages defaults to Node 18.

### Telegram auth not working
→ Set `TELEGRAM_BOT_TOKEN` on Railway. Without it, only the mock dev user (id: 999999) will authenticate.

